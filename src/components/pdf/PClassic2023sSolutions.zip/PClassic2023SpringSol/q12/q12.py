import math
import time

d = 20

s = input()
t = input()

st = time.time()


n = len(s)
sgen = [""] * 400
for i in range(n):
    c = ord(s[i]) - 97
    for k in range(d):
        sgen[c * d + k] += s[i]
        if c != k:
             sgen[k * d + c] += s[i]

m = len(t)
tgen = [""] * 400
for i in range(m):
    c = ord(t[i]) - 97
    for k in range(d):
        tgen[c * d + k] += t[i]
        if c != k:
            tgen[k * d + c] += t[i]

adj = [False] * 400
for i in range(d):
    for j in range(d):
        adj[i * d + j] = (sgen[i * d + j] == tgen[i * d + j])

valid = [False] * 1048576
valid[0] = True
for i in range(20):
    valid[1 << i] = (sgen[i * d + i] == tgen[i * d + i])

for i in range(1, 1048576):
    lb = int(math.log2(i & -i))
    ub = i.bit_length() - 1
    valid[i] = (adj[lb * d + ub] and valid[i^(1<<lb)] and valid[i^(1<<ub)])

best = 0
bbitcnt = 0
for i in range(1, 1048576):
    idc = i
    idc = (idc & 0x5555555555555555) + ((idc & 0xAAAAAAAAAAAAAAAA) >> 1)
    idc = (idc & 0x3333333333333333) + ((idc & 0xCCCCCCCCCCCCCCCC) >> 2)
    idc = (idc & 0x0F0F0F0F0F0F0F0F) + ((idc & 0xF0F0F0F0F0F0F0F0) >> 4)
    idc = (idc & 0x00FF00FF00FF00FF) + ((idc & 0xFF00FF00FF00FF00) >> 8)
    idc = (idc & 0x0000FFFF0000FFFF) + ((idc & 0xFFFF0000FFFF0000) >> 16)
    idc = (idc & 0x00000000FFFFFFFF) + ((idc & 0xFFFFFFFF00000000) >> 32)
    if valid[i] and bbitcnt < idc:
        best = i
        bbitcnt = idc
    
occ = [False] * d
for i in range(n):
    occ[ord(s[i]) - 97] = True

for i in range(m):
    occ[ord(t[i]) - 97] = True

ans = []

for i in range(d):
    if occ[i] and best & (1 << i) != 0:
        ans.append(chr(97 + i))

print(len(ans))
print("".join(ans))

# print(time.time() - st)


