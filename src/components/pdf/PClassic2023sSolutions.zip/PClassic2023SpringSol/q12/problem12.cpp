#include <bits/stdc++.h>
using namespace std;

#pragma GCC target("lzcnt,popcnt")

constexpr int d = 26;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	string s;
	cin >> s;
	string t;
	cin >> t;

	int n = s.size();
	string sgen[d][d]{};
	for(int i = 0; i < n; i++) {
		int c = s[i]-'a';
		for(int k = 0; k < d; k++) {
			sgen[c][k] += s[i];
			if(c != k) sgen[k][c] += s[i];
		}
	}

	int m = t.size();
	string tgen[d][d]{};
	for(int i = 0; i < m; i++) {
		int c = t[i]-'a';
		for(int k = 0; k < d; k++) {
			tgen[c][k] += t[i];
			if(c != k) tgen[k][c] += t[i];
		}
	}

	// for(int i = 0; i < d; i++) {
	// 	for(int j = 0; j < d; j++) {
	// 		cout << sgen[i][j] << " ";
	// 	}
	// 	cout << endl;
	// }

	bool adj[d][d]{false};
	for(int i = 0; i < d; i++) {
		for(int j = 0; j < d; j++) {
			adj[i][j] = (sgen[i][j] == tgen[i][j]);
		}
	}

	bool valid[1<<d]{false};
	valid[0] = true;
	for(int i = 0; i < d; i++) {
		valid[1<<i] = (sgen[i][i] == tgen[i][i]);
	}

	for(unsigned int i = 1; i < (1<<d); i++) {
		int lb = __builtin_ffs(i)-1, ub = 31-__builtin_clz(i);
		valid[i] = adj[lb][ub] && valid[i^(1<<lb)] && valid[i^(1<<ub)];
	}

	unsigned int best = 0;
	for(unsigned int i = 1; i < (1<<d); i++) {
		if(valid[i] && __builtin_popcount(best) < __builtin_popcount(i)) best = i;
	}

	bool occ[d]{false};
	for(int i = 0; i < n; i++) {
		occ[s[i]-'a'] = true;
	}
	for(int i = 0; i < m; i++) {
		occ[t[i]-'a'] = true;
	}

	string ans = "";

	for(int i = 0; i < d; i++) {
		if(occ[i] && ((best&(1<<i)) != 0)) {
			ans += ((char)('a'+i));
		}
	}

	cout << ans.size() << endl;
	cout << ans << endl;

	return 0;
}