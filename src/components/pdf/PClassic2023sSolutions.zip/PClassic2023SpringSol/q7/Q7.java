import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int[] p = new int[N];
        int[] b = new int[N];
        
        for(int i = 0; i < N; i++) p[i] = sc.nextInt();
        for(int i = 0; i < N; i++) b[i] = sc.nextInt();
        
        int ans = Integer.MIN_VALUE;
        
        for(int i = 0; i < N; i++) {
            int cur = 0;
            for(int j = 0; j < N; j++) {
                int diff = Math.abs(p[i] - p[j]);
                if(diff <= b[j]) {
                    cur += b[j] - diff;
                } 
            }
            ans = Math.max(ans, cur);
        }
    
    System.out.println(ans);
        
        
    }
}