#include <bits/stdc++.h>

using namespace std;

int main() {
    int N; cin >> N;
    int p[N], b[N];
    for(int i = 0; i < N; i++)
        cin >> p[i];
    for(int i = 0; i < N; i++) 
        cin >> b[i];

    
    int ans = -INT_MAX;
    
    for(int i = 0; i < N; i++) {
        int cur = 0;
        for(int j = 0; j < N; j++) {
            int diff = abs(p[i] - p[j]);
            if(diff <= b[j]) {
                cur += b[j] - diff;
            } 
        }
        ans = max(ans, cur);
    }
    
    cout << ans << "\n";
}
