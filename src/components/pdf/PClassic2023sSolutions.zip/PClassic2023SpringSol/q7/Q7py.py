def q7(n, positions, brightnesses):
    position_brightnesses = [0 for _ in range(n)]
    for i in range(n):
        for j in range(n):
            position_brightnesses[i] += max(0, brightnesses[j] - abs(positions[j] - positions[i]))
    return max(position_brightnesses)


n = int(input().strip().split(' ')[0])
positions = input().strip().split(' ')
brightnesses = input().strip().split(' ')
positions = [int(x) for x in positions]
brightnesses = [int(x) for x in brightnesses]
print(q7(n, positions, brightnesses))
