if __name__ == "__main__":
    ab = input()
    ab = ab.split(" ")
    a = int(ab[0])
    b = int(ab[1])
    print(a % b)
    