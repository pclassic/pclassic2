import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q1 {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String ab = reader.readLine();
        String[] abArray = ab.split(" ");
        int a = Integer.parseInt(abArray[0]);
        int b = Integer.parseInt(abArray[1]);
        System.out.println(a % b);
    }
}