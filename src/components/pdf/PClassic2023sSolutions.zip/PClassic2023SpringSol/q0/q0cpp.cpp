// Description: You are given three pieces of data per test case. The first piece of data is a single integer k. The second piece of data is a string s. The third piece of data is four space-separated integers a, b, c, d. 

// For each test case:
// Print the value that is one more than k.
// Print the string s with the letter “a” appended to the end of it on a new line
// Print the sum of a, b, c, d  on a new line

#include <iostream>

using namespace std;

int main(int argc, char* argv[]) {
    int numTestCases;
    cin >> numTestCases;
    for (int i = 0; i < numTestCases; i++) {
        int k, a, b, c, d;
        string s;
        cin >> k >> s >> a >> b >> c >> d;

        cout << k + 1 << endl;
        cout << s + "a" << endl;
        cout << a + b + c + d << endl;
    }
}