// Description: You are given three pieces of data per test case. The first piece of data is a single integer k. The second piece of data is a string s. The third piece of data is four space-separated integers a, b, c, d. 

// For each test case:
// Print the value that is one more than k.
// Print the string s with the letter “a” appended to the end of it on a new line
// Print the sum of a, b, c, d  on a new line
import java.io.BufferedReader;
import java.io.InputStreamReader;


public class q0question {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int numTestCases = Integer.parseInt(reader.readLine());
        for (int i = 0; i < numTestCases; i++) {
            String k = reader.readLine();
            String s = reader.readLine();
            String abcd = reader.readLine();
            String[] abcdArray = abcd.split(" ");
            int a = Integer.parseInt(abcdArray[0]);
            int b = Integer.parseInt(abcdArray[1]);
            int c = Integer.parseInt(abcdArray[2]);
            int d = Integer.parseInt(abcdArray[3]);
            System.out.println(Integer.parseInt(k) + 1);
            System.out.println(s + "a");
            System.out.println(a + b + c + d);
        }
    }
}