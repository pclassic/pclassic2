"""Description: You are given three pieces of data per test case. The first piece of data is a single integer k. The second piece of data is a string s. The third piece of data is four space-separated integers a, b, c, d. 
For each test case:
Print the value that is one more than k.
Print the string s with the letter “a” appended to the end of it on a new line
Print the sum of a, b, c, d  on a new line"""

if __name__ == "__main__":
    numtestcases = int(input())
    for i in range(numtestcases):
        k = int(input())
        s = input()
        a, b, c, d = input().split(" ", 3)
        a = int(a)
        b = int(b)
        c = int(c)
        d = int(d)
        print(k + 1)
        print(s + "a")
        print(a + b + c + d)
    