import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.ArrayList;
import java.util.Queue;
import java.util.ArrayDeque;

public class q8c {
    static class Node {
        int x;
        int y;
        long level;

        Node(int x, int y, long level) {
            this.x = x; this.y = y; this.level = level;
        }
    }

    static class Neighbors {
        List<Node> neighbors;

        Neighbors() {
            neighbors = new ArrayList<>();
        }
    }

    static void q8(int n, long[] heights) {
        Neighbors[][] graph = new Neighbors[n][n];

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                graph[i][j] = new Neighbors();
                if (heights[i] == heights[j]) {
                    for (int di: new int[]{-1, 1}) {
                        for (int dj: new int[]{-1, 1}) {
                            int ni = i + di;
                            int nj = j + dj;

                            if (ni >= 0 && ni < n && nj >= 0 && nj < n && heights[ni] == heights[nj]) {
                                graph[i][j].neighbors.add(new Node(ni, nj, 0));
                            }
                        }
                    }
                }
            }
        }

        Queue<Node> q = new ArrayDeque<>();
        boolean[][] visited = new boolean[n][n];
        q.add(new Node(0, n - 1, 0));

        while (!q.isEmpty()) {
            Node node = q.remove();
            int x = node.x;
            int y = node.y;
            long level = node.level;

            if (x == n - 1 && y == 0) {
                System.out.println(level);
                return;
            }

            for (Node neighbor: graph[x][y].neighbors) {
                int nx = neighbor.x;
                int ny = neighbor.y;

                if (!visited[nx][ny]) {
                    visited[nx][ny] = true;
                    q.add(new Node(nx, ny, level + 1));
                }
            }
    
        }
    }

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(reader.readLine());
        

        long[] heights = new long[n];
        int curr = 0;
        for (String height: reader.readLine().split(" ")) {
            heights[curr++] = Long.parseLong(height);
        }

        q8(n, heights);
    }
}