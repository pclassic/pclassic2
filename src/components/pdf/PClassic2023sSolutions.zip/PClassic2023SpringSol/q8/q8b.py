n = int(input().strip().split(' ')[0])
heights = input().strip().split(' ')
heights = [int(x) for x in heights]

graph = [[[] for _ in range(n)] for _ in range(n)]


for i in range(n):
    for j in range(n):
        neighbors = [(i + 1, j - 1), (i - 1, j - 1),
                     (i + 1, j + 1), (i - 1, j + 1)]

        for nx, ny in neighbors:
            if nx >= 0 and nx < n and ny >= 0 and ny < n and heights[nx] == heights[ny]:
                graph[i][j].append((nx, ny))

q = [(0, n-1, 0)]
visited = set()
while q:
    x, y, level = q.pop(0)
    if (x, y) == (n - 1, 0):
        print(level)

    for nx, ny in graph[x][y]:
        if (nx, ny) not in visited:
            visited.add((nx, ny))
            q.append((nx, ny, level + 1))
