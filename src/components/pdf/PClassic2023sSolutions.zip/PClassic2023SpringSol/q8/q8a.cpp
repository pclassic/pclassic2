#include <deque>
#include <iostream>
#include <unordered_set>
#include <vector>

#define ll long long
#define mp make_pair

using namespace std;

int main(int argc, char* argv[]) {
    ll n;
    cin >> n;
    ll heights[n];

    for (ll i = 0; i < n; ++i) {
        cin >> heights[i];
    }

    // vertices are [0..n-1] x [0..n-1]

    vector<pair<ll, ll>> graph[n][n];
    bool visited[n][n];

    for (ll l = 0; l < n; ++l) {
        for (ll r = 0; r < n; ++r) {
            visited[l][r] = false;
            if (heights[l] != heights[r]) {
                continue;
            }

            pair<ll, ll> neighbors[4]{
                mp(l + 1, r - 1),
                mp(l - 1, r - 1),
                mp(l + 1, r + 1),
                mp(l - 1, r + 1),
            };

            for (auto& neighbor : neighbors) {
                ll new_l = neighbor.first;
                ll new_r = neighbor.second;

                if (new_l >= 0 && new_l < n && new_r >= 0 && new_l < n &&
                    heights[new_l] == heights[new_r]) {
                    graph[l][r].push_back(neighbor);
                }
            }
        }
    }

    deque<pair<ll, ll>> q;
    pair<ll, ll> parent[n][n];

    q.push_back(mp(0, n - 1));

    while (!q.empty()) {
        pair<ll, ll> curr = q.front();
        q.pop_front();
        ll l = curr.first;
        ll r = curr.second;

        if (l == n - 1 && r == 0) {
            break;
        }

        for (auto neighbor : graph[l][r]) {
            auto n_x = neighbor.first;
            auto n_y = neighbor.second;

            if (!visited[n_x][n_y]) {
                visited[n_x][n_y] = true;
                parent[n_x][n_y] = mp(l, r);
                q.push_back(mp(n_x, n_y));
            }
        }
    }

    pair<ll, ll> curr = mp(n - 1, 0);
    deque<pair<ll, ll>> moves;
    ll count = 0;

    while (curr.first != 0 || curr.second != n - 1) {
        curr = parent[curr.first][curr.second];
        ++count;
    }

    cout << count << endl;
}
