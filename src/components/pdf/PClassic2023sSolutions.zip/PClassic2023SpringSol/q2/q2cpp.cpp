#include <iostream>
#include <algorithm>

using namespace std;


int main(int argc, char* argv[]) {
    int t;
    cin >> t;
    for (int i = 0; i < t; i++) {
        int arr[4];
        for (int j = 0; j < 4; j++) {
            cin >> arr[j];
        }
        sort(arr, arr+4);
        cout << max(abs(arr[0] + arr[1]), abs(arr[2] + arr[3])) << endl;

    }
}