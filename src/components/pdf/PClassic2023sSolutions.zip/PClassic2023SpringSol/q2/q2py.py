def findMaxAbsSum(arr):
    arr.sort()
    print(max(abs(arr[0] + arr[1]), abs(arr[2] + arr[3])))

if __name__ == "__main__":
    tests = int(input())
    for _ in range(tests):
        arr = input().split(' ') # size 4
        intarr = [int(x) for x in arr]
        findMaxAbsSum(intarr)