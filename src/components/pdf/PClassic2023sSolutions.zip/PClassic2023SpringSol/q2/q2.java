import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;

public class q2 {
    public static void findMaxAbsSum(int[] arr) {
        Arrays.sort(arr);
        System.out.println(Math.max(Math.abs(arr[0] + arr[1]), Math.abs(arr[arr.length - 1] + arr[arr.length - 2])));

    }

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.valueOf(reader.readLine());
        for (int i = 0; i < t; i++) {
            int[] arr = new int[4];
            String input = reader.readLine();
            String[] str = input.split(" ");
            for (int a = 0; a < 4; a++) {
                arr[a] = Integer.valueOf(str[a]);
            }
            findMaxAbsSum(arr);
        }
    }
}