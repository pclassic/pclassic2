//chris paul :0
#include <bits/stdc++.h>

using namespace std;

#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define mp(a, b) make_pair(a, b)
#define pb push_back
#define f first
#define s second
#define nl '\n'
#define sz(v) (long long) v.size()

#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}

typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;

const ll inf = 1e16;

const int MOD = 1e9 + 7;
typedef decay<decltype(MOD)>::type T;
struct mi {
    T val;
    explicit operator T() const { return val; }
    mi() { val = 0; }
    mi(const long long& v) {
        val = (-MOD <= v && v < MOD) ? v : v % MOD;
        if (val < 0) val += MOD; }
    friend ostream& operator<<(ostream& os, const mi& a) { return os << a.val; }
    friend bool operator==(const mi& a, const mi& b) { return a.val == b.val; }
    friend bool operator!=(const mi& a, const mi& b) { return !(a == b); }
    friend bool operator<(const mi& a, const mi& b) { return a.val < b.val; }
    mi operator-() const { return mi(-val); }
    mi& operator+=(const mi& m) {
        if ((val += m.val) >= MOD) val -= MOD;
        return *this; }
    mi& operator-=(const mi& m) {
        if ((val -= m.val) < 0) val += MOD;
        return *this; }
    mi& operator*=(const mi& m) { val = (long long) val * m.val % MOD;
        return *this; }
    friend mi pow(mi a, long long p) {
        mi ans = 1; assert(p >= 0);
        for (; p; p /= 2, a *= a) if (p & 1) ans *= a;
        return ans; }
    friend mi inv(const mi& a) { assert(a != 0); return pow(a, MOD - 2); }
    mi& operator/=(const mi& m) { return (*this) *= inv(m); }
    friend mi operator+(mi a, const mi& b) { return a += b; }
    friend mi operator-(mi a, const mi& b) { return a -= b; }
    friend mi operator*(mi a, const mi& b) { return a *= b; }
    friend mi operator/(mi a, const mi& b) { return a /= b; }
};

vector<int> vals = {1, 5, 10, 25, 100};

const int mx = 1e6;
vector<int> fib;

const int mxb = 2000;
bool dp[mxb + 1][mxb + 1];
bool ndp[mxb + 1];
int mn[mxb + 1];


void solve() {
    int ret = -1;
    int n; cin >> n;
    if (n <= mxb) {
        for (int f: fib) {
            if (f > mxb) break;
            if (dp[f][n]) {
                ret = f;
                break;
            }
        }
        cout << ret << nl;
        return;
    }

    // find the minimum number of coins
    int m = 0;
    // 1, 5, 10, 25, 100
    int nm[5];
    vector<int> avail;
    for (int i = 4; i >= 0; i--) {
        nm[i] = n / vals[i];
        n %= vals[i];
        m += nm[i];
        if (i < 4 && i > 0) {
            for (int j = 0; j < nm[i]; j++) avail.pb(vals[i]);
        }
    }

    // check if m is a fibonacci number
    if (m == *lower_bound(fib.begin(), fib.end(), m)) {
        cout << m << nl;
        return;
    }

    int f1 = *upper_bound(fib.begin(), fib.end(), m);
    int f2 = *upper_bound(fib.begin(), fib.end(), f1);

    int k = f1 - m;
    if (k >= 5 || k == 3) {
        cout << f1 << nl;
        return;
    }

    ret = f2;

    set<int> vis;

    vector<int> pos = {0};
    for (int v: avail) {
        int sz = sz(pos);
        for (int i = 0; i < sz; i++) {
            if (vis.find(pos[i] + v) == vis.end()) {
                pos.pb(pos[i] + v);
                vis.insert(pos[i] + v);
            }
        }
    }



    assert(sz(pos) < 100);
    for (int p: pos) {
        if (dp[mn[p] + k][p] || dp[mn[p + 100] + k][p + 100]) {
            ret = f1;
            break;
        }
    }

    cout << ret << nl;
}

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL);
    fib.pb(1);
    fib.pb(1);

    // generate fibonacci numbers up to 10^6
    while (fib.back() <= mx) {
        int sz = sz(fib);
        fib.pb(fib[sz - 1] + fib[sz - 2]);
    }
    ms(dp, 0);
    ms(ndp, 0);
    ms(mn, 0);
    dp[0][0] = 1;
    for (int i = 0; i < mxb; i++) {
        for (int j = 0; j < mxb; j++) {
            if (dp[i][j]) {
                for (int v: vals) {
                    if (v + j <= mxb) {
                        ndp[v + j] = 1;
                    }
                }
            }
        }
        for (int j = 0; j <= mxb; j++) {
            dp[i + 1][j] = ndp[j];
            ndp[j] = 0;
            if (dp[i + 1][j] && mn[j] == 0) {
                mn[j] = i + 1;
            }
        }
    }

    int t; cin >> t;
    while (t--) {
        solve();
    }
}