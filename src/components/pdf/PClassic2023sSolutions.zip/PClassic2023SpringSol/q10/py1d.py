maxN = 1e9;
fib = [];

NICKELS = 0
DIMES = 1
QUARTERS = 2
DOLLARS = 3

# Populates list of all fib numbers up to maxN
def dp():
    fib.append(0)
    fib.append(1)
    while fib[-1] < maxN:
        fib.append(fib[-1] + fib[-2])

# Find next index of next fib number >= elt
def findNext(currIndex, elt):
    while currIndex < len(fib):
        num = fib[currIndex]
        if num >= elt:
            return currIndex, num
        currIndex += 1
    return -1, None

def solve ():
    n = int(input())

    # Minimum number of coins needed to make n (=m)
    pennies = n % 5
    nickels = ((n % 25) // 5) % 2
    dimes = (n % 25) // 10
    quarters = (n % 100) // 25
    dollars = n // 100

    m = pennies + nickels + dimes + quarters + dollars

    # dp_total[i]: Can make n with m+i coins
    dp_total = [False for _ in range(n - m + 1)]
    dp_total[0] = True
    
    # dp_coins[i]: If true above, the number of each coin used
    dp_coins = [0 for _ in range((n - m + 1) * 4)]
    dp_coins[0] = nickels
    dp_coins[1] = dimes
    dp_coins[2] = quarters
    dp_coins[3] = dollars

    # First fib number >= m
    index, ans = findNext(0, m)

    for i in range(0, n - m + 1):
        if ans == i + m:
            if dp_total[i]:
                print(ans)
                return
            else:
                index, ans = findNext(index, ans + 1)
                continue

        if not dp_total[i]:
            continue

        if dp_coins[4*i+1] >= 1:
            dp_total[i + 1] = True
            dp_coins[4*i] = dp_coins[4*i] + 2
            dp_coins[4*(i + 1)+1] = dp_coins[4*i+1] - 1
            dp_coins[4*(i + 1)+2] = dp_coins[4*i+2]
            dp_coins[4*(i + 1)+3] = dp_coins[4*i+3]

        if dp_coins[4*i+2] >= 1:
            if dp_coins[4*i] >= 1:
                dp_total[i + 1] = True
                dp_coins[4*(i + 1)] = dp_coins[4*i] - 1
                dp_coins[4*(i + 1)+1] = dp_coins[4*i+1] + 3
                dp_coins[4*(i + 1)+2] = dp_coins[4*i+2] - 1
                dp_coins[4*(i + 1)+3] = dp_coins[4*i+3]
            else:
                dp_total[i + 2] = True
                dp_coins[4*(i + 2)] = dp_coins[4*i] + 1
                dp_coins[4*(i + 2)+1] = dp_coins[4*i+1] + 2
                dp_coins[4*(i + 2)+2] = dp_coins[4*i+2] - 1
                dp_coins[4*(i + 2)+3] = dp_coins[4*i+3]

        if dp_coins[4*i+3] >= 1:
            if dp_coins[4*i] >= 2:
                dp_total[i + 2] = True
                dp_coins[4*(i + 2)] = dp_coins[4*i] - 2
                dp_coins[4*(i + 2)+1] = dp_coins[4*i+1] + 1
                dp_coins[4*(i + 2)+2] = dp_coins[4*i+2] + 4
                dp_coins[4*(i + 2)+3] = dp_coins[4*i+3] - 1
            else:
                dp_total[i + 3] = True
                dp_coins[4*(i + 3)] = dp_coins[4*i]
                dp_coins[4*(i + 3)+1] = dp_coins[4*i+1]
                dp_coins[4*(i + 3)+2] = dp_coins[4*i+2] + 4
                dp_coins[4*(i + 3)+3] = dp_coins[4*i+3] - 1

        if dp_coins[4*i] >= 1:
            dp_total[i + 4] = True
            dp_coins[4*(i + 4)] = dp_coins[4*i] - 1
            dp_coins[4*(i + 4)+1] = dp_coins[4*i+1]
            dp_coins[4*(i + 4)+2] = dp_coins[4*i+2]
            dp_coins[4*(i + 4)+3] = dp_coins[4*i+3]

    print(-1)

if __name__ == "__main__":
    dp()
    t = int(input())
    while t > 0:
        solve()
        t -= 1