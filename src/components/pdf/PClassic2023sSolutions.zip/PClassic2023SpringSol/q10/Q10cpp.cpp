#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int mxN = 1e9;
vector<int> fib;

int t, n;

void dp() {
    fib.push_back(1);
    fib.push_back(2);
    for (int i = 1; fib[i] < mxN; i++) {
        fib.push_back(fib[i - 1] + fib[i]);
    }
}

void solve () {
    cin >> n;

    int pennies = n % 5;
    int nickels = ((n % 25) / 5) % 2;
    int dimes = (n % 25) / 10;
    int quarters = (n % 100) / 25;
    int dollars = n / 100;

    int m = pennies + nickels + dimes + quarters + dollars;

    int f_1 = *lower_bound(fib.begin(), fib.end(), m);
    int f_2 = *upper_bound(fib.begin(), fib.end(), f_1);

    if (f_1 > n) {
        cout << -1 << '\n';
        return;
    }

    if (m == f_1) {
        cout << f_1 << '\n';
        return;
    }

    if (n < 100) {
        if (m == 9 || m == 10) {
            cout << f_1 << '\n';
        } else if (m == 4 || m == 7) {
            cout << ((dimes >= 1) ? f_1 : -1) << '\n';
        } else if (m == 6) {
            cout << ((dimes == 2 || quarters >= 1) ? f_1 : -1) << '\n';
        } else {
            cout << -1 << '\n';
        }
        return;
    }

    int d_1 = f_1 - m;
    
    if (d_1 != 1 && d_1 != 2 && d_1 != 4) {
        cout << f_1 << '\n';
        return;
    }

    if (d_1 == 2) {
        cout << ((dimes == 2 || quarters >= 1) ? f_1 : f_2) << '\n';
        return;
    }

    if (d_1 == 4) {
        cout << ((dimes >= 1 || quarters >= 1 || nickels >= 1) ? f_1 : f_2) << '\n';
        return;
    }

    if (d_1 == 1) {
        if (dimes >= 1) {
            cout << f_1 << '\n';
            return;
        }

        int d_2 = f_2 - m;

        if (d_2 != 4) {
            cout << f_2 << '\n';
        } else {
            cout << ((quarters >= 1 || nickels >= 1) ? 8 : 13) << '\n';
        }
        return;
    }
}

int main () {
    dp();
    cin >> t;
    while (t--) {
        solve();
    }
}