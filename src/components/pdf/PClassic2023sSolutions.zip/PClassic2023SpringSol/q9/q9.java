import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.*;


public class q9 {

    public static long murderLess(int[][] grid, int srcr, int srcy, int endr, int endy) {
        int[] d = {0, 1, 0, -1, 0};
            int m = grid.length, n = grid[0].length;
            long[][] dist = new long[m][n];
            for (long[] di : dist) {
                Arrays.fill(di, Long.MAX_VALUE);
            }
            dist[srcr - 1][srcy -1] = grid[srcr - 1][srcy - 1];
            PriorityQueue<long[]> pq = new PriorityQueue<>(Comparator.comparingLong(a -> a[0]));
            pq.offer(new long[]{dist[srcr - 1][srcy - 1], srcr - 1,  srcy - 1});
            while (!pq.isEmpty()) {
                long[] cur = pq.poll();
                long o = cur[0];
                int r = (int) cur[1], c = (int) cur[2];
                if (r == endr - 1 && c == endy - 1) {
                    return o;
                }
                for (int k = 0; k < 4; ++k) {
                    int i = r + d[k], j = c + d[k + 1];
                    if (0 <= i && i < m && 0 <= j && j < n && o + grid[i][j] < dist[i][j]) {
                        dist[i][j] = o + grid[i][j];
                        pq.offer(new long[]{dist[i][j], i, j});
                    }
                }
            }

        return dist[endr - 1][endy - 1];
    }



    public static void main(String args[]) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String[] firstLine = reader.readLine().split(" ");
        int rows = Integer.parseInt(firstLine[0]);
        int cols = Integer.parseInt(firstLine[1]);
        int[][] res = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            String[] currLine = reader.readLine().split(" ");
            for (int j = 0; j < cols; j++) {
                res[i][j] = Integer.parseInt(currLine[j]);
            }
        }
        String[] line = reader.readLine().split(" ");
        String[] line2 = reader.readLine().split(" ");
        System.out.println(murderLess(res, Integer.parseInt(line[0]), Integer.parseInt(line[1]),
                Integer.parseInt(line2[0]), Integer.parseInt(line2[1])));

    }
}
