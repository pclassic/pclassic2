from queue import PriorityQueue
from math import inf

def murderLess(grid, srcr, srcc, endr, endc):
    srcr -= 1 
    srcc -= 1 
    endr -= 1 
    endc -= 1 
    rows = len(grid)
    cols = len(grid[0])
    dist = [[inf]*len(i) for i in grid]

    dist[srcr][srcc] = grid[srcr][srcc]
    queue = PriorityQueue()
    obj = (dist[srcr][srcc], (srcr, srcc))
    queue.put(obj)

    while queue:
        currDist, currNode = queue.get()
        currr = currNode[0]
        currc = currNode[1]
        if (currr == endr and currc == endc):
            return currDist

        neighbors = [(currr - 1, currc), (currr + 1, currc), (currr, currc - 1), (currr, currc + 1)]
        for i in neighbors:
            r = i[0] 
            c = i[1] 
            if (0 <= r and r < rows and 0 <= c and c < cols and (currDist + grid[r][c]) < dist[r][c]):
                dist[r][c] = currDist + grid[r][c]
                queue.put((dist[r][c], (r, c)))

        
dimensions = input().strip().split(' ')
rows = int(dimensions[0])
cols = int(dimensions[1])
grid = [[0 for _ in range(cols)] for _ in range(rows)]
for r in range(rows):
    temp = input().strip().split(' ')
    i = 0
    for c in range(cols):
        grid[r][c] = int(temp[i])
        i += 1
source = input().strip().split(' ')
src = [int(i) for i in source]
endpoint = input().strip().split(' ')
end = [int(i) for i in endpoint]

print(murderLess(grid, src[0], src[1], end[0], end[1]))
