#include <bits/stdc++.h>
using namespace std;

int query(int i, int j) {
	cout << "? " << (i+1) << " " << (j+1) << endl;
	cout.flush();
	int ret;
	cin >> ret;
	return ret;
}

int f(int a, int b) {
	return (a^b)+b;
}

void solve() {
	int n;
	cin >> n;

	int a[n];

	int x = query(0, 1);
	int y = query(1, 0);

	a[0] = 0;
	a[1] = 0;
	for(int d = 0; d < 30; d++) {
		int m = (1<<(d+1))-1;
		for(int b = 0; b < 4; b++) {
			a[0] = a[0] ^ ((b%2)<<d);
			a[1] = a[1] ^ ((b/2)<<d);
			if(((f(a[0],a[1])&m) == (x&m)) && ((f(a[1],a[0])&m) == (y&m))) break;
			a[0] = a[0] ^ ((b%2)<<d);
			a[1] = a[1] ^ ((b/2)<<d);
		}
	}
	
	for(int i = 2; i < n; i++) {
		int q = query(i, 0);
		a[i] = (q-a[0])^a[0];
	}

	cout << "! ";
	for(int i = 0; i < n; i++) {
		cout << a[i] << " ";
	}
	cout << endl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	int t;
	cin >> t;
	while(t--) {
		solve();
	}
	return 0;
}