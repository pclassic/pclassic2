import sys

def query(i, j):
    print("?", i+1, j+1)
    sys.stdout.flush()
    return int(input())

def f(a, b):
    return (a ^ b) + b

def solve():
    n = int(input())
    a = [0] * n

    x = query(0, 1)
    y = query(1, 0)
    
    for d in range(30):
        m = (1 << (d + 1)) - 1
        for b in range(4):
            a[0] = a[0] ^ ((b % 2) << d);
            a[1] = a[1] ^ ((b // 2) << d);
            if ((f(a[0], a[1]) & m) == (x & m)) and ((f(a[1], a[0]) & m) == (y & m)):
                break
            a[0] = a[0] ^ ((b % 2) << d);
            a[1] = a[1] ^ ((b // 2) << d);

    for i in range(2, n):
        q = query(i, 0)
        a[i] = (q - a[0]) ^ a[0]

    print("!", end = "", flush = False)
    for i in range(n):
        print(" " + str(a[i]), end = "", flush = False)
    print(flush = True)

def main():
    t = int(input())
    for _ in range(t): 
        solve()

main()