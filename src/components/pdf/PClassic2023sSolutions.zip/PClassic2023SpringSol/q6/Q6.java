import java.util.*;
import java.io.*;

public class Main {

    static int move(char dir, int n) {
        if (dir == 'R') {
            return ++n;
        } else {
            return --n;
        }
    }

    static int solve(int n, int c, int r, int len, String path) {
        int num_moves = 0;
        int curr_c = c;
        int curr_r = r;
        for (int i = 0; i < len; i++) {
            char direction = path.charAt(i);
            curr_c = (move(direction, curr_c) + n) % n;
            if (curr_c == curr_r) {
                curr_r = (move(direction, curr_r) + n) % n;
                num_moves++;
            }
        }
        return num_moves;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String[] info = reader.readLine().split(" "); // n, c, r, length

        int n = Integer.parseInt(info[0]); // size of number line
        int c = Integer.parseInt(info[1]); // initial location of c
        int r = Integer.parseInt(info[2]); // initial location of r
        int len = Integer.parseInt(info[3]); // size of c's path

        String path = reader.readLine();
        System.out.println(solve(n, c, r, len, path));
    }
}