params = input().split(" ")
path = input()

n = int(params[0])
cop = int(params[1])
robber = int(params[2])
pathLength = params[3]

moves = 0
for direction in path:
    cop = (cop + (1 if direction == "R" else -1)) % n
    if cop == robber:
        robber = (robber + (1 if direction == "R" else -1)) % n
        moves += 1

print(moves)
