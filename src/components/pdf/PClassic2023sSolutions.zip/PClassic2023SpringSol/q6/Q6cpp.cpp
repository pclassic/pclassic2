#include <iostream>
#include <string>

using namespace std;

#define ll long long

ll n, c, r;
int l;
string path;

int main() {
    cin >> n >> c >> r >> l >> path;

    int ans = 0;

    for (int i = 0; i < l; i++) {
        if (path[i] == 'L') {
            c = ((c + n) - 1) % n;
            if (c == r) {
                r = ((r + n) - 1) % n;
                ans++;
            }
        } else {
            c = (c + 1) % n;
            if (c == r) {
                r = (r + 1) % n;
                ans++;
            }
        }
    }

    cout << ans << '\n';
    return 0;
}