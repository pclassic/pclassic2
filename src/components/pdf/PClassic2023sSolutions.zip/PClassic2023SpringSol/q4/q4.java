import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;
import java.util.Arrays;

public class q4 {
    public static void matchingSubstring(String s, String bin) {
        Set<Character> set = new HashSet<>(Arrays.asList('a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'));
        String converteds = "";
        for (int i = 0; i < s.length(); i++) {
            if (set.contains(s.charAt(i))) {
                converteds += "1";
            } else {
                converteds += "0";
            }
        }
        int count = 0;
        for (int i = 0; i < s.length() - bin.length() + 1; i++) {
            if (converteds.substring(i, i+bin.length()).equals(bin)) {
                count++;
            }
        }
        System.out.println(count);
    }

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String s = reader.readLine();
        String bin = reader.readLine();
        matchingSubstring(s, bin);
    }
}