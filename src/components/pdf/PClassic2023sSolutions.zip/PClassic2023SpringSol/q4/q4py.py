def matchingSubstring(s1, s2):
    total = 0
    vowels = ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']
    converteds1 = ""
    for ch in s1:
        if ch in vowels:
            converteds1 += "1"
        else:
            converteds1 += "0"
    for i in range(len(converteds1) - len(s2) + 1):
        if converteds1[i:i + len(s2)] == s2:
            total += 1
    print(total)

if __name__ == "__main__":
    s1 = input()
    s2 = input()
    matchingSubstring(s1, s2)