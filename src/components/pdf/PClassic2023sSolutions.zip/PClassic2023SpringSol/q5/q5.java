import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q5 {
    public static long minSteps(long a, long b){
        if (a == 1) {
            return b;
        }
        long steps = 0;
        long radix = 1;

        while (radix <= b) {
            radix *= a;
        }

        while (b > 0) {
            long times = b / radix;
            b -= radix * times;
            steps += times;
            radix /= a;
        }
        return steps;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        long t = Integer.parseInt(reader.readLine());
        for (long i = 0; i < t; i++) {
            String[] temp = reader.readLine().split(" ");
            long a = Integer.parseInt(temp[0]);
            long b = Integer.parseInt(temp[1]);
            long output = minSteps(a, b);
            System.out.println(output);
        }
    }
}
