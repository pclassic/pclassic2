# Implement the following function
def solution(a, b):
    if a == 1:
        return b
    steps = 0
    radix = 1
    while radix <= b:
        radix *= a

    while b > 0:
        times = b // radix
        b -= radix * times
        steps += times
        radix //= a

    return steps


# Do not modify below this line
tests = int(input())
for test in range(tests):
    arr = input().strip().split(' ')
    a = int(arr[0])
    b = int(arr[1])
    print(solution(a, b))