#include <iostream>
#include <set>

using namespace std;


int main(int argc, char* argv[]) {
    int n;
    cin >> n;
    set<int> vals;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int q;
            cin >> q; 
            vals.insert(q);
        }
    }
    for (int i = 1; i <= n*n; i++) {
        if (!vals.count(i)) {
            cout << i << endl;
            break;
        }
    }


}