if __name__ == "__main__":
    size = int(input())
    count = [0 for i in range(size**2)]
    for i in range(size):
        arr = input().split(" ")
        for ele in arr:
            if int(ele) != -1:
                count[int(ele) - 1] += 1
    for i in range(len(count)):
        if count[i] == 0:
            print(i + 1)
