import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

public class q3 {
    public static void findMissing(int[][] arr) {
        Set<Integer> set = new HashSet<Integer>();
        int n = arr[0].length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                set.add(arr[i][j]);
            }
        }
        for (int i = 1; i <= n*n; i++) {
            if (!set.contains(i)) {
                System.out.println(i);
                return;
            }
        }

    }

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.valueOf(reader.readLine());
        int[][] arr = new int[n][n];
        for (int i = 0; i < n; i++) {
           //  int[] arr = new int[4];
            String input = reader.readLine();
            String[] str = input.split(" ");
            for (int a = 0; a < n; a++) {
                arr[i][a] = Integer.valueOf(str[a]);
            }
        }
        findMissing(arr);
    }
}