def arrayCollect(k, a):
    runningSum = 0
    maxVal = a[0] * k
    for i in range(1,len(a)):
        if k - i + 1 <= 0:
            break
        total = runningSum + a[i]*(k-i+1)
        if total > maxVal:
            maxVal = total
        if (i != 0):
            runningSum += a[i]
    print(maxVal)
if __name__ == "__main__":
    n, k = [int(i) for i in input().split()]
    a = [int(x) for x in input().split()]
    arrayCollect(k, a)
