#include <iostream>
#include <vector>

using namespace std;

int sumArray(vector<int> a, int lo, int hi) {
    int sum = 0;
    for (int i = lo; i < hi + 1; i++) {
        sum += a[i];
    }
    return sum;
}

int arrayCollection(int turns, vector<int> a) {
    int maxObjs = turns * a[0];
    for (int x = 1; x <= turns; x++) {
        if (x >= a.size()) break;
        int numObjs = sumArray(a, 1, x) + (turns-x)*a[x];
        maxObjs = max(maxObjs, numObjs);
    }
    return maxObjs;
}


int main(int argc, char* argv[]) {
    int n, k;
    cin >> n >> k;
    vector<int> a;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        a.push_back(x);
    }
    cout << arrayCollection(k, a) << endl;


}