import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q5java {
    private static int arrayCollection(int turns, int[] a) {
        int maxObjs = turns * a[0];
        for (int x = 1; x <= turns; x++) {
            if (x >= a.length) break;
            int numObjs = sumArray(a, 1, x) + (turns-x)*a[x];
            maxObjs = Integer.max(maxObjs, numObjs);
        }
        return maxObjs;
    }

    private static int sumArray(int[] arr, int lo, int hi) {
        int sum = 0;
        for (int i = lo; i < hi+1; i++) {
            sum += arr[i];
        }
        return sum;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] par = br.readLine().split(" ");
        int n = Integer.parseInt(par[0]);
        int k = Integer.parseInt(par[1]);
        String[] aStrings = br.readLine().split(" ");
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = Integer.parseInt(aStrings[i]);
        }

        System.out.println(Integer.toString(arrayCollection(k, a)));
    }
}