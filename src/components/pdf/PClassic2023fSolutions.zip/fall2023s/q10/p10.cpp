#pragma once
 
#include <algorithm>
#include <array>
#include <bitset>
#include <cassert>
#include <chrono>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iostream>
#include <iomanip>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <random>
#include <set>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>
 
using namespace std;
 
#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define mp(a, b) make_pair(a, b)
#define pb push_back
#define f first
#define s second
#define nl '\n'
#define sz(v) (long long) v.size()
 
#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}
 
typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;
 
void solve() {
    int n, k;
    ll m, h; 
    cin >> n >> m >> h >> k;
    vector<ll> arr(n);
    for (int i = 0; i < n; i++) cin >> arr[i];
 
    vector<ll> mn(n + 1);
    vector<int> ret;
 
    mn[n] = 1;
    bool pos = 1;
 
    for (int i = n - 1; i >= 0; i--) {
        // x - a + h >= mn[i + 1]
        // x >= mn[i + 1] + a - h
        mn[i] = max(1LL, mn[i + 1] + arr[i] - h);
        if (mn[i] > m) {
            pos = 0;
            break;
        }
    }
 
    if (!pos) {
        cout << -1 << nl;
        return;
    }
 
    ll curh = m;
    int lh = -1;
    for (int i = 0; i < n; i++) {
        if (i <= lh) {
            // in the middle of a heal spell
            curh = min(m, curh - arr[i] + h);
            continue;
        }
 
        // we must heal here
        if (curh - arr[i] < mn[i + 1]) {
            ret.pb(i);
            curh = min(m, curh - arr[i] + h);
            lh = i + k - 1;
        } else {
            curh -= arr[i];
        }
    }
 
    cout << sz(ret);
    for (int p : ret) {
        cout << " " << p + 1;
    }
    cout << endl;
}
 
int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL);
 
    solve();
}
