#pragma once

#include <algorithm>
#include <array>
#include <bitset>
#include <cassert>
#include <chrono>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iostream>
#include <iomanip>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <random>
#include <set>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;

#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define mp(a, b) make_pair(a, b)
#define pb push_back
#define f first
#define s second
#define nl '\n'
#define sz(v) (long long) v.size()

#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}

typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;

const ll inf = 1e16;

const int MOD = 1e9 + 7;
typedef decay<decltype(MOD)>::type T;
struct mi {
    T val;
    explicit operator T() const { return val; }
    mi() { val = 0; }
    mi(const long long& v) {
        val = (-MOD <= v && v < MOD) ? v : v % MOD;
        if (val < 0) val += MOD; }
    friend ostream& operator<<(ostream& os, const mi& a) { return os << a.val; }
    friend bool operator==(const mi& a, const mi& b) { return a.val == b.val; }
    friend bool operator!=(const mi& a, const mi& b) { return !(a == b); }
    friend bool operator<(const mi& a, const mi& b) { return a.val < b.val; }
    mi operator-() const { return mi(-val); }
    mi& operator+=(const mi& m) {
        if ((val += m.val) >= MOD) val -= MOD;
        return *this; }
    mi& operator-=(const mi& m) {
        if ((val -= m.val) < 0) val += MOD;
        return *this; }
    mi& operator*=(const mi& m) { val = (long long) val * m.val % MOD;
        return *this; }
    friend mi pow(mi a, long long p) {
        mi ans = 1; assert(p >= 0);
        for (; p; p /= 2, a *= a) if (p & 1) ans *= a;
        return ans; }
    friend mi inv(const mi& a) { assert(a != 0); return pow(a, MOD - 2); }
    mi& operator/=(const mi& m) { return (*this) *= inv(m); }
    friend mi operator+(mi a, const mi& b) { return a += b; }
    friend mi operator-(mi a, const mi& b) { return a -= b; }
    friend mi operator*(mi a, const mi& b) { return a *= b; }
    friend mi operator/(mi a, const mi& b) { return a /= b; }
};

void solve() {
    // n, health, damage
    int n, h, d; cin >> n >> h >> d;
    // ordering
    vector<int> arr(n);
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
        arr[i]--;
    }

    // try every possible ordering
    vector<int> v(n);
    for (int i = 0; i < n; i++) {
        v[i] = i;
    }

    int best = n * (h / d + 1);
    int best_pos = (n * (h + d) - 1) / (n * d);

    do {
        // 0 -> n - 1 is our side 
        // n -> 2n - 1 is their side
        // health remaining
        // number of guys attacking

        bool alive[2 * n]; int curhealth[2 * n], attackers[2 * n];

        for (int i = 0; i < n; i++) {
            curhealth[i] = h;
            curhealth[i + n] = h;
            alive[i] = 1;
            alive[i + n] = 1;
        }
        
        int cur = 0;
        int tot = 0;

        while (cur < n) {
            
            ms(attackers, 0);
            for (int i = 0; i < n; i++) {
                attackers[v[cur] + n] += alive[i];
            }
            for (int i = n; i < 2 * n; i++) {
                attackers[arr[i - n]] += alive[i];
            }

            int nt = -1;
            for (int i = 0; i < 2 * n; i++) {
                ll td = d * attackers[i];
                if (!alive[i] || td == 0) continue;
                int t = (curhealth[i] + td - 1) / td; 
                if (nt < 0 || nt > t) {
                    nt = t;
                }
            }

            // check if we kill
            if (attackers[v[cur] + n] * d * nt >= curhealth[v[cur] + n]) {
                for (int i = 0; i < 2 * n; i++) {
                    if (!alive[i]) continue;
                    curhealth[i] -= attackers[i] * d * (nt - 1);
                    assert(curhealth[i] > 0);
                }

                // roll over 
                int avail = attackers[v[cur] + n];
                while (avail > 0 && cur < n) {
                    int need = (curhealth[v[cur] + n] + d - 1) / d;
                    attackers[v[cur] + n] = min(avail, need);
                    if (need <= avail) cur++;
                    avail -= min(avail, need);
                }

                for (int i = 0; i < 2 * n; i++) {
                    if (!alive[i]) continue;
                    curhealth[i] -= attackers[i] * d;
                    if (curhealth[i] <= 0) alive[i] = 0;
                }
            } else {
                // we don't kill so just update the things
                for (int i = 0; i < 2 * n; i++) {
                    if (!alive[i]) continue;
                    curhealth[i] -= attackers[i] * d * nt;
                    if (curhealth[i] <= 0) alive[i] = 0;
                }
            }
            tot += nt;
        }
        best = min(best, tot);
        if (best == best_pos) break;
    } while (next_permutation(v.begin(), v.end()));

    cout << best << endl;
}

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL);

    int t = 1;
    while (t--) {
        solve();
    }
}