#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<int,int> pii;

/*
n q
t_1 t_2 ... t_n (t_i\in {0,1})
p_1 p_2 ... p_n
l_1 r_1 b_1
l_2 r_2 b_2
...
l_q r_q b_q
*/

int score = 0;

struct Node {
	Node *l = 0, *r = 0;
	int lo, hi;

	using T = array<ll,4>; // type (max blue power, max red power, min change needed to flip some node, total score)
	T e = {LONG_LONG_MIN/2, LONG_LONG_MIN/2, LONG_LONG_MAX/2, 0}; // identity
	T val = e; // value
	T f(T a, T b) { // associate fn
		T c;
		c[0] = max(a[0], b[0]);
		c[1] = max(a[1], b[1]);
		c[2] = min(min(a[2], b[2]), (c[0] > c[1]) ? (c[0]-c[1]) : (LONG_LONG_MAX/2));
		c[3] = a[3]+b[3]+(c[1] >= c[0]);
		return c;
	}
	using U = ll;
	void upd(U x) {
		if(!pr) pv = 0; // if no updates yet, init
		val[1] += x, val[2] -= x; // update val
		pv += x; // update lazy push
	}
	bool pr = false;
	U pv = 0;

	Node(int lo,int hi):lo(lo),hi(hi){} // Large interval of e
	Node(const vector<T>& v, int lo, int hi) : lo(lo), hi(hi) {
		if (lo + 1 < hi) {
			int mid = lo + (hi - lo)/2;
			l = new Node(v, lo, mid); r = new Node(v, mid, hi);
			val = f(l->val, r->val);
			score += (val[0] <= val[1]);
		}
		else val = v[lo];
	}
	T query(int L, int R) {
		if (R <= lo || hi <= L) return e;
		if (L <= lo && hi <= R) return val;
		push();
		return f(l->query(L, R), r->query(L, R));
	}
	void update(int L, int R, U x) {
		if (R <= lo || hi <= L) return;
		if (L <= lo && hi <= R && !(val[2] > 0 && val[2]-x <= 0)) {
			upd(x);
			pr = true;
		}
		else {
			push(), l->update(L, R, x), r->update(L, R, x);
			val = f(l->val, r->val);
		}
	}
	void push() {
		if (!l) {
			int mid = lo + (hi - lo)/2;
			l = new Node(lo, mid); r = new Node(mid, hi);
		}
		if (pr) {
			l->update(lo,hi,pv), r->update(lo,hi,pv), pr = false;
		}	
	}
	~Node() {
		delete l;
		delete r;
	}
};

void solve() {
	int n, q;
	cin >> n >> q;
	vi t(n);
	for(int i = 0; i < n; i++) {
		cin >> t[i];
	}
	vi p(n);
	for(int i = 0; i < n; i++) {
		cin >> p[i];
	}
	vector<array<ll,3>> qu(q);
	for(int i = 0; i < q; i++) {
		cin >> qu[i][0] >> qu[i][1] >> qu[i][2];
		qu[i][0]--;
	}


	int rp = 0;
	for(int x : t) rp += x;

	vector<array<ll,4>> segvec(n);
	for(int i = 0; i < n; i++) {
		array<ll,4> cur = {LONG_LONG_MIN/2, LONG_LONG_MIN/2, LONG_LONG_MAX/2, t[i]};
		cur[t[i]] = p[i];
		segvec[i] = cur;
	}
	unique_ptr<Node> tree = make_unique<Node>(segvec, 0, n);

	for(auto [l, r, b] : qu) {
		tree->update(l, r, b);
		array<ll,4> ans = tree->query(0, n);
		// for(int x : ans) cout << x << " ";
		// cout << nl;
		cout << (ans[3]-rp) << nl;
	}
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	solve();
	return 0;
}