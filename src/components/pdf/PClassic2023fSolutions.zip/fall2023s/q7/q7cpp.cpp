#include <iostream>
#include <vector>

using namespace std;

int seeingPeople(vector<int> people) {
    vector<int> numBlocking;
    for (int i = 0; i < people.size(); i++) {
        numBlocking.push_back(0);
    }
    int largest = -1;
    int secondLargest = -1;
    int largestIndex = -1;
    for (int i = 0; i < people.size(); i++) {
        if (people[i] > largest) {
            secondLargest = largest;
            largest = people[i];
            largestIndex = i;
        } else if (people[i] > secondLargest) {
            secondLargest = people[i];
            numBlocking[largestIndex] += 1;
        }
    }
    int maxBlocking = -1;
    int maxIndex = -1;
    for (int i = 0; i < numBlocking.size(); i++) {
        if (numBlocking[i] > maxBlocking) {
            maxBlocking = numBlocking[i];
            maxIndex = i;
        }
    }
    return maxIndex;
}


int main(int argc, char* argv[]) {
    int n;
    vector<int> people; 
    cin >> n;
    for (int i=0; i < n; i++) {
        int p;
        cin >> p;
        people.push_back(p);
    }
    cout << (seeingPeople(people)+1) << endl;

}