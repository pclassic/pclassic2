def seeingPeople(people):
    numBlocking = [0 for x in range(len(people))]
    largest = -1
    secondLargest = -1
    largestIndex = -1
    # not done yet needs some tweaks
    for i in range(len(people)):
        if people[i] > largest: # this means that this will be the new largest and that nothing is blocking this guy
            secondLargest = largest
            largest = people[i]
            largestIndex = i
        elif people[i] > secondLargest: # this means that if the largest is removed then we would be able to see this guy
            secondLargest = people[i]
            numBlocking[largestIndex] += 1
        # if neither of the above conditions are met then we can't see this person no matter what so we don't care
    maxIndex = numBlocking.index(max(numBlocking))
    print(maxIndex+1)

if __name__ == "__main__":
    n = int(input())
    people = [int(x) for x in input().split()]
    seeingPeople(people)
