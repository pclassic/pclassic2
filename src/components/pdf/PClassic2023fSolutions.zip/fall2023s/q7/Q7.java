import java.util.*;
public class Q7 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] ppl = new int[n];
        for(int i = 0; i < n; i++) {
            ppl[i] = in.nextInt();
        }
        int[] numblock = new int[n];
        int larg = -1;
        int seclarg = -1;
        int largind = -1;
        for(int i = 0; i < n; i++) {
            if(ppl[i] > larg) {
                seclarg = larg;
                larg = ppl[i];
                largind = i;
            } else if(ppl[i] > seclarg) {
                seclarg = ppl[i];
                numblock[largind]++;
            }
        }
        int max = numblock[0];
        int ind = 0;
        for(int i = 1; i < numblock.length; i++) {
            if(numblock[i] > max) {
                ind = i;
                max = numblock[i];
            }
        }
        System.out.println(ind+1);
    }
}