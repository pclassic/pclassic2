
def flex(n):
    i = 0
    factorials = [1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 
                3628800, 39916800, 479001600]
    while (factorials[i] <= n):
        i += 1
        if (i == 12):
            break
    i-=1

    answer = ""
    while (i >= 0):
        quot = n // factorials[i]
        # if quot >= 10 then we need to use letters
        if (quot >= 10):
            if (quot == 10):
                answer += "A"
            elif (quot == 11):
                answer += "B"
            elif (quot == 12):
                answer += "C"
            elif (quot == 13):
                answer += "D"
            elif (quot == 14):
                answer += "E"
            elif (quot == 15):
                answer += "F"
        else:
            answer += str(quot)
        n = n % factorials[i]
        i -= 1
    return answer


if __name__ == "__main__":
    n = int(input())
    print(flex(n))