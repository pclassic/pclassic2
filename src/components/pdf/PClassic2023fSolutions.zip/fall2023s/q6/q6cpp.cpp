#include <iostream>
#include <vector>
#include <string>

using namespace std;


string flex(int n) {
    int i = 0;
    int factorials[] = { 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800, 39916800, 479001600 };
    while (factorials[i] <= n) {
        i++;
        if (i == 12){
            break;
        }
    }
    i--;
    string answer = "";
    while (i >= 0) {
        int quotient = n / factorials[i];
        n = n % factorials[i];
        if (quotient >= 10) {
            char c = quotient + 55;
            answer += c;
        }
        else {
            answer += to_string(quotient);
        }
        i--;
    }
    return answer;
}


int main(int argc, char* argv[]) {
    int n;
    cin >> n;
    cout << flex(n) << endl;


}