import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q6java {
    private static String flex(int n) {
        int i = 0;
        int[] factorials = {1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 
                            3628800, 39916800, 479001600};
        while (factorials[i] <= n) {
            i++;
            if (i == factorials.length){
                break;
            }
        }
        i-=1;
        String answer = "";
        while (i >= 0) {
            int quot = n / factorials[i];
            if (quot >= 10) {
                answer += (char) (quot + 55);
            }
            else {
                answer += Integer.toString(quot);
            }
            n = n % factorials[i];
            i--;
        }
        return answer;
    }


    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        System.out.println(flex(n));
    }
}