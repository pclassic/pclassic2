#include <bits/stdc++.h>
#define rows 5

using namespace std;

string alph[rows];
string str;
map<char, int> m;

int memo[25][25][10005];

int solve(int i, char a[2]) {
    if (i == str.length()) return 0; //end of string
    int ans = INT_MAX;
    
    int x = m[a[0]];
    int y = m[a[1]];
    int z = m[str[i]];
    
    if (memo[x][y][i] != 10) {
        return memo[x][y][i];
    }
    
    ans = min(ans, solve(i + 1, new char[2] {str[i], a[1]}) + max(abs(x % 5 - z % 5), abs(x / 5 - z / 5)) + 1);
    ans = min(ans, solve(i + 1, new char[2] {a[0], str[i]}) + max(abs(y % 5 - z % 5), abs(y / 5 - z / 5)) + 1);
    
    memo[x][y][i] = ans;
    return ans; 
}

int main() {
    //I/O stuff
    char l, r;
    for (int i = 0; i < 5; i++){
       cin >> alph[i]; 
    } 
    cin >> l >> r >> str;
    
    for (int i = 0;i < 25; i++) {
        for (int j = 0; j < 25; j++) {
            for (int k = 0; k < 10005; k++) {
                memo[i][j][k] = 10;
            }
        }
    }
    
    for (int i =0; i < 5; i++){
        for (int j = 0; j < 5; j++) {
            m[alph[i][j]] = i * 5 + j;
        }
    }
  
    cout << solve(0, new char[2] {l, r}) << '\n';
    return 0;    
}