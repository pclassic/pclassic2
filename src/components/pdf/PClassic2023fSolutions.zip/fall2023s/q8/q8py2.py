import sys
import math
 
sys.setrecursionlimit(10000)
 
rows = 5
alph = ["" for _ in range(rows)]  
s = ""
m = {}
dp = [10000000 for _ in range(100000*25)]
 
if __name__ == "__main__":
    # I/O and such
    for i in range(5):
        alph[i] = input()  
        
    lr = input().split()
    l, r = lr[0], lr[1]

    s = input()
    n = len(s)
    
    for i in range(5):
        for j in range(5):
            m[alph[i][j]] = (i*5 + j)

    dp[0*25+m[r]] = max(abs(m[l]%5 - m[s[0]]%5), abs(m[l]//5 - m[s[0]]//5)) + 1
    dp[0*25+m[l]] = max(abs(m[r]%5 - m[s[0]]%5), abs(m[r]//5 - m[s[0]]//5)) + 1

    for i in range(1, n):
        y = m[s[i-1]]
        z = m[s[i]]
        for j in range(25):
            dp[i*25+j] = min(dp[i*25+j], dp[(i-1)*25+j] + max(abs(y%5 - z%5), abs(y//5 - z//5)) + 1)
        for j in range(25):
            dp[i*25+y] = min(dp[i*25+y], dp[(i-1)*25+j] + max(abs(j%5 - z%5), abs(j//5 - z//5)) + 1)

    ans = 10000000
    for j in range(25):
        ans = min(ans, dp[(n-1)*25+j])
    
    print(ans)