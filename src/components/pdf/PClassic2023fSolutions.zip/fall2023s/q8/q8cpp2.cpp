#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<int,int> pii;

constexpr int MAXS = 100'000;
constexpr int d = 26;
int dp[MAXS][d];
const int INF = 1e7;

vector<int> cx(d), cy(d);
inline int diff(int a, int b) {
	return max(abs(cx[a]-cx[b]), abs(cy[a]-cy[b]));
}

void solve() {
	vector<string> g(5);
	for(int i = 0; i < 5; i++) {
		cin >> g[i];
	}
	char l, r;
	cin >> l >> r;
	string s;
	cin >> s;

	int n = sz(s);

	for(int i = 0; i < 5; i++) {
		for(int j = 0; j < 5; j++) {
			cx[g[i][j]-'a'] = j;
			cy[g[i][j]-'a'] = i;
		}
	}

	for(int i = 0; i < d; i++) {
		dp[0][i] = INF;
	}
	dp[0][l-'a'] = diff(s[0]-'a', r-'a');
	dp[0][r-'a'] = diff(s[0]-'a', l-'a');
	for(int i = 1; i < n; i++) {
		for(int j = 0; j < d; j++) {
			dp[i][j] = dp[i-1][j]+diff(s[i-1]-'a',s[i]-'a');
		}
		for(int j = 0; j < d; j++) {
			dp[i][s[i-1]-'a'] = min(dp[i][s[i-1]-'a'], dp[i-1][j]+diff(j, s[i]-'a'));
		}
	}

	int ans = INF;
	for(int i = 0; i < d; i++) {
		ans = min(ans, dp[n-1][i]);
	}
	ans += n;

	cout << ans << endl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	solve();
	return 0;
}