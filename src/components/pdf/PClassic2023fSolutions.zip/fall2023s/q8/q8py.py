import sys
import math

sys.setrecursionlimit(20000)

rows = 5
alph = ["" for _ in range(rows)]  
str = ""
m = {}
memo = [[[10 for _ in range(10005)] for _ in range(25)] for _ in range(25)]

def solve(i, l, r):
    if i == len(str):
        return 0
    
    ans = math.inf
    
    x = m[l] 
    y = m[r]
    z = m[str[i]]
    
    if memo[x][y][i] != 10:
        return memo[x][y][i]
        
    ans = min(ans, solve(i+1, str[i], r) + max(abs(x%5 - z%5), abs(x//5 - z//5)) + 1) 
    ans = min(ans, solve(i+1, l, str[i]) + max(abs(y%5 - z%5), abs(y//5 - z//5)) + 1)
    
    memo[x][y][i] = ans
    return ans

if __name__ == "__main__":
    # I/O and such
    for i in range(5):
        alph[i] = input()  
        
    lr = input().split()
    l, r = lr[0], lr[1]
    
    str = input()
    
    for i in range(5):
        for j in range(5):
            m[alph[i][j]] = i*5 + j
            
    print(solve(0, l, r))