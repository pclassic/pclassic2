#include <iostream>
#include <vector>

using namespace std;


int main(int argc, char* argv[]) {
    int m;
    cin >> m;
    int num_p;
    cin >> num_p;
    vector<int> ps;
    for (int i=0; i < num_p; i++) {
        int p;
        cin >> p;
        ps.push_back(p);
    }
    int num_q;
    cin >> num_q;
    vector<int> qs;
    for (int i=0; i < num_q; i++) {
        int q;
        cin >> q;
        m += q;
    }
    for (int i = 0; i < num_p; i++) {
        m *= ps[i];
    }
    cout << m << endl;

}