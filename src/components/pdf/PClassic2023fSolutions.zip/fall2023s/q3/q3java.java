import java.util.*;
import java.io.*;
public class q3java {
    public static void main(String[] args) throws IOException {
       BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
       int m = Integer.parseInt(in.readLine());
       int p = Integer.parseInt(in.readLine());
       int[] mult = new int[p];
       String[] line = in.readLine().split(" ");
       for(int i = 0; i < p; i++) {
           mult[i] = Integer.parseInt(line[i]);
       }
        int q = Integer.parseInt(in.readLine());
        int[] add = new int[q];
        line = in.readLine().split(" ");
        for(int i = 0; i < q; i++) {
            m += Integer.parseInt(line[i]);
        }
        for(int i: mult) {
            m *= i;
        }
        System.out.println(m);
    }
}