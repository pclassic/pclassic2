def coupon(m, mult, add):
    ans = m
    for i in add:
        ans += i
    for i in mult:
        ans *= i
    return ans

    

if __name__ == "__main__":
    m = int(input())
    p = int(input())
    mult = [int(x) for x in input().split()]
    q = int(input())
    add = [int(x) for x in input().split()]
    print(coupon(m, mult, add))

