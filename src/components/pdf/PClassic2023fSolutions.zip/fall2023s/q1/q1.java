import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q1 {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String ab = reader.readLine();
        if (ab.charAt(0) == 'P' || ab.charAt(0) == 'C' || ab.charAt(0) == 'L' || ab.charAt(0) == 'A' || ab.charAt(0) == 'S' || ab.charAt(0) == 'I') {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }
}