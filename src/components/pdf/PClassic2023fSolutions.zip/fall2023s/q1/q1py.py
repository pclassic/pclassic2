if __name__ == "__main__":
    ab = input()
    if ab[0] == 'P' or ab[0] == 'L' or ab[0] == 'C' or ab[0] == 'A' or ab[0] == 'S' or ab[0] == 'I':
        print("YES")
    else:
        print("NO")