#include <iostream>

using namespace std;


int main(int argc, char* argv[]) {
    string s;
    cin >> s;
    if (s[0] == 'P' || s[0] == 'C' || s[0] == 'L' || s[0] == 'A' || s[0] == 'S' || s[0] == 'I') {
        cout << "YES" << endl;
    } else {
        cout << "NO" << endl;
    }
}