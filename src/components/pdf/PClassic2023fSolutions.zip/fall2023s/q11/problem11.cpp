#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<int,int> pii;

constexpr int MOD = 1e9+7;
constexpr int N = 200'005;
vi phi(N);
vector<ll> sum(N);

void solve() {
	int n;
	cin >> n;

	cout << (sum[n] % MOD) << nl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);

	for(int i = 0; i < N; i++) {
		phi[i] = i;
	}
	for(int i = 1; i < N; i++) {
		for(int j = 2*i; j < N; j += i) {
			phi[j] -= phi[i];
		}
	}
	for(int i = 1; i < N; i++) {
		sum[i] = sum[i-1] + phi[i];
	}

	int t;
	cin >> t;
	while(t--) {
		solve();
	}
	return 0;
}