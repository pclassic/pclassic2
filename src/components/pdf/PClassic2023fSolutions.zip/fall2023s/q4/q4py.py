from typing import List 

def rectangle_cut(x: int, y: int, hlines: List[int], vlines: List[int]):
    xmax = max_diff(x, hlines)
    ymax = max_diff(y, vlines)
    return xmax*ymax

def max_diff(ub: int, lines: List[int]):
    if lines[0] != 0: lines = [0] + lines
    if lines[-1] != ub: lines.append(ub)
    diffs = [lines[i+1] - lines[i] for i in range(len(lines) - 1)]
    return max(diffs)

if __name__ == "__main__":
    x, y = [int(dim) for dim in input().split()]
    n = int(input())
    hlines = [int(x) for x in input().split()]
    m = int(input())
    vlines = [int(y) for y in input().split()]
    print(rectangle_cut(x, y, hlines, vlines))