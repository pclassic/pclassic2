import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q4java {
    private static int rectangleCut(int x, int y, int[] xlines, int[] ylines) {
        int xmax = maxDiff(x, xlines);
        int ymax = maxDiff(y, ylines);
        return xmax*ymax;
    }

    private static int maxDiff(int ub, int[] lines) {
        int maxDiff = lines[0];
        for (int i = 0; i < lines.length-1; i++) {
            maxDiff = Integer.max(maxDiff, lines[i+1] - lines[i]);
        }
        maxDiff = Integer.max(maxDiff, ub - lines[lines.length-1]);
        return maxDiff;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] dims = br.readLine().split(" ");
        int x = Integer.parseInt(dims[0]);
        int y = Integer.parseInt(dims[1]);

        int n = Integer.parseInt(br.readLine());
        String[] xStrings = br.readLine().split(" ");
        int[] xlines = new int[n];
        for (int i = 0; i < n; i++) {
            xlines[i] = Integer.parseInt(xStrings[i]);
        }

        int m = Integer.parseInt(br.readLine());
        String[] yStrings = br.readLine().split(" ");
        int[] ylines = new int[m];
        for (int i = 0; i < m; i++) {
            ylines[i] = Integer.parseInt(yStrings[i]);
        }

        System.out.println(Integer.toString(rectangleCut(x, y, xlines, ylines)));
    }
}