#include <iostream>
#include <vector>

using namespace std;

int maxDiff(int ub, vector<int> lines) {
    int maxDiff = lines[0];
    for (int i =0; i < lines.size() - 1; i++) {
        maxDiff = max(maxDiff, lines[i+1] - lines[i]);
    }
    maxDiff = max(maxDiff, ub - lines[lines.size() - 1]);
    return maxDiff;
}

int rectangleCut(int x, int y, vector<int> xlines, vector<int> ylines) {
    return maxDiff(x, xlines) * maxDiff(y, ylines);
}


int main(int argc, char* argv[]) {
    int x, y;
    cin >> x >> y;
    int n;
    cin >> n;
    vector<int> xlines;
    for (int i=0; i < n; i++) {
        int xline;
        cin >> xline;
        xlines.push_back(xline);
    }
    int m;
    cin >> m;
    vector<int> ylines;
    for (int i=0; i < m; i++) {
        int yline;
        cin >> yline;
        ylines.push_back(yline);
    }
    cout << rectangleCut(x, y, xlines, ylines) << endl;

}