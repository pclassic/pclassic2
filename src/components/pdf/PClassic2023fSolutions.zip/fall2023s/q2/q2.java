import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q2 {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(reader.readLine().trim());
        for (int i = 0; i < t; i++) {
            String ab = reader.readLine();
            String[] abArray = ab.split(" ");
            int n = Integer.parseInt(abArray[0]);
            int k = Integer.parseInt(abArray[1]);
            int sum = n+k;
            int digits = 0;
            while (sum > 0) {
                sum /= 10;
                digits++;
            }
            int n_digits = 0;
            while (n > 0) {
                n /= 10;
                n_digits++;
            }
            if (digits > n_digits) {
                System.out.println("YES");
            } else {
                System.out.println("NO");
            }
        }
    }
}