

if __name__ == "__main__":
    tests = int(input())
    for _ in range(tests):
        arr = input().split(' ') # size 4
        n = int(arr[0])
        k = int(arr[1])
        sum = n + k
        digits = 0
        while sum > 0:
            sum = sum // 10
            digits += 1
        n_digits = 0
        while n > 0:
            n = n // 10
            n_digits += 1
        if n_digits < digits:
            print("YES")
        else:
            print("NO")