#include <iostream>

using namespace std;


int main(int argc, char* argv[]) {
    int t;
    cin >> t;
    for (int j=0; j < t; j++) {
        int n, k;
        cin >> n >> k;
        int sum = n+k;
        int digits = 0;
        while (sum > 0) {
            sum /= 10;
            digits++;
        }
        int n_digits = 0;
        while (n > 0) {
            n /= 10;
            n_digits++;
        }
        if (n_digits < digits) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
    }
}