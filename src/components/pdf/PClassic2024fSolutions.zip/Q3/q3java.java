import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q3java {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        int t = Integer.parseInt(br.readLine());

        while (t-- > 0) {
            String[] firstLine = br.readLine().split(" ");
            int n = Integer.parseInt(firstLine[0]);
            int b = Integer.parseInt(firstLine[1]);
            
            System.out.println(maxDigit(n, b));
        }
    }
    
    public static int maxDigit(int n, int b) {
        int m = 0;
        while (n != 0) {
            m = Math.max(m, n % b);
            n /= b;
        }
        return m;
    }
}