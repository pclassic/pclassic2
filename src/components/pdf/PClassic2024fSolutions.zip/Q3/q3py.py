def max_digit(n : int, b : int) -> int:
    m = 0
    while n:
        m = max(m, n % b)
        n //= b
    return m

if __name__ == "__main__":
    t = int(input())
    
    while (t:= t-1) >= 0:
        n, b = map(int, input().split())
        m = max_digit(n, b)
        print(m)