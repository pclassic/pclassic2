#include <iostream>
#include <vector>
#include <cmath>
#include <string>
using namespace std;

int max_digit(int n, int b) {
    int m = 0;
    while (n != 0) {
        m = max(m, n % b);
        n /= b;
    }
    return m;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    cin >> t;

    int n, b;
    while (t--) {
        cin >> n >> b;
        cout << max_digit(n, b) << endl;
    }

    return 0;
}