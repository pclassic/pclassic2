import sys
sys.setrecursionlimit(300000)
n,m,a,b = map(int,input().split())
a-=1
b-=1
edges = [[] for i in range(n)]
for i in range(m):
    x,y = map(int,input().split())
    x-=1
    y-=1
    edges[x].append(y)
    edges[y].append(x)
seen1 = []
seen2 = []
visited = [0]*n
def dfs(curr,bad,add):
    if visited[curr] or curr == bad: return
    visited[curr]=1
    add.append(curr)
    for i in edges[curr]:
        dfs(i,bad,add)
dfs(a,b,seen1)
visited = [0]*n
dfs(b,a,seen2)
seen1 = set(seen1)
seen2 = set(seen2)
a1 = len([x for x in seen1 if x not in seen2])-1
a2 = len([x for x in seen2 if x not in seen1])-1
print(a1*a2)
