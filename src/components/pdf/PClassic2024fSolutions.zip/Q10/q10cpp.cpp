#include <iostream>
#include <vector>
#include <set>

using namespace std;

#define f0r(i, n) for (int i = 0; i < n; i++)
using vi = vector<int>;
using vvi = vector<vi>;

void dfs(int curr, int bad, const vvi& edges, vi& visited, set<int>& seen) {
    if (visited[curr] || curr == bad) return;
    visited[curr] = 1;
    seen.insert(curr);
    for (int neighbor : edges[curr]) {
        dfs(neighbor, bad, edges, visited, seen);
    }
}

int count_pairs(int n, int m, const vvi& edges, int a, int b) {
    set<int> seen1, seen2;
    vi visited(n, 0);

    dfs(a, b, edges, visited, seen1); // dfs on a, avoid b

    fill(visited.begin(), visited.end(), 0);
    dfs(b, a, edges, visited, seen2); // dfs on b, avoid a

    // count exclusive
    int a1 = 0, a2 = 0;
    for (int node : seen1) {
        if (seen2.find(node) == seen2.end()) a1++;
    }
    for (int node : seen2) {
        if (seen1.find(node) == seen1.end()) a2++;
    }

    return (a1-1) * (a2-1); // -1 to exclude source
}

int main() {
    // cin.tie(nullptr);
    // ios::sync_with_stdio(false);

    int n, m;
    cin >> n >> m;

    int a, b;
    cin >> a >> b;
    a--; b--; // 0-index

    vvi edges(n);
    for (int i = 0; i < m; i++) {
        int x, y;
        cin >> x >> y;
        x--; y--; // 0-index
        edges[x].push_back(y);
        edges[y].push_back(x);
    }

    cout << count_pairs(n, m, edges, a, b) << endl;
    return 0;
}
