import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class q10java {
    static ArrayList<Integer>[] edges;
    static boolean[] visited;

    static void dfs(int curr, int bad, ArrayList<Integer> add) {
        if (visited[curr] || curr == bad) return;
        visited[curr] = true;
        add.add(curr);
        for (int i : edges[curr]) {
            dfs(i, bad, add);
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] firstLine = br.readLine().split(" ");
        int n = Integer.parseInt(firstLine[0]);
        int m = Integer.parseInt(firstLine[1]);
        int a = Integer.parseInt(firstLine[2]) - 1;
        int b = Integer.parseInt(firstLine[3]) - 1;

        edges = new ArrayList[n];
        for (int i = 0; i < n; i++) {
            edges[i] = new ArrayList<>();
        }

        for (int i = 0; i < m; i++) {
            String[] edgeLine = br.readLine().split(" ");
            int x = Integer.parseInt(edgeLine[0]) - 1;
            int y = Integer.parseInt(edgeLine[1]) - 1;
            edges[x].add(y);
            edges[y].add(x);
        }

        ArrayList<Integer> seen1 = new ArrayList<>();
        ArrayList<Integer> seen2 = new ArrayList<>();
        visited = new boolean[n];

        dfs(a, b, seen1);
        visited = new boolean[n];
        dfs(b, a, seen2);

        Set<Integer> set1 = new HashSet<>(seen1);
        Set<Integer> set2 = new HashSet<>(seen2);

        int a1 = (int) seen1.stream().filter(x -> !set2.contains(x)).count() - 1;
        int a2 = (int) seen2.stream().filter(x -> !set1.contains(x)).count() - 1;

        System.out.println(a1 * a2);
    }

    
}

