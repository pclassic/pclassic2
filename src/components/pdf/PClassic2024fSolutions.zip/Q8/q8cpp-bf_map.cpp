// C++ brute force solution using map (should TLE/MLE for longer test cases)

#include <iostream>
#include <vector>
#include <array>
#include <set>
#include <map>

#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx,avx2,fma")

using namespace std;

#define f0r(i, n) for (int i = 0; i < n; i++)
using vi = vector<int>;
using vvi = vector<vi>;

int rush_hour_ez(int n, int m, const vvi& grid) {
    
    vector<array<int, 3>> cars;
    f0r(i, n) {
        f0r(j, m) {
            if (grid[i][j] == 1) {
                cars.push_back({i, j, 1});
            } else if (grid[i][j] == 2) {
                cars.push_back({i, j, 2});
            }
        }
    }

    int exiting_cars = 0;
    while (!cars.empty()) {
        vector<array<int, 3>> new_cars;
        map<pair<int, int>, int> positions; // position : n cars
        set<pair<int, int>> crashes;

        for (auto& car : cars) {
            int r = car[0];
            int c = car[1];
            int dir = car[2];

            int new_r = r + (dir == 2);
            int new_c = c + (dir == 1);

            if (new_r >= n || new_c >= m) {
                ++exiting_cars;
                continue;
            }

            pair<int, int> pos = {new_r, new_c};
            positions[pos]++;

            if (positions[pos] > 1) {
                crashes.insert(pos);
            } else {
                new_cars.push_back({new_r, new_c, dir});
            }
        }

        cars.clear();
        for (auto& car : new_cars) {
            pair<int, int> pos = {car[0], car[1]};
            if (crashes.count(pos) == 0) {
                cars.push_back(car);
            }
        }
    }

    return exiting_cars;
}

int main() {
    cin.tie(nullptr);
    ios::sync_with_stdio(false);

    int n, m;
    cin >> n >> m;

    vvi grid(n, vi(m));
    f0r(i, n) {
        f0r(j, m) {
            cin >> grid[i][j];
        }
    }

    cout << rush_hour_ez(n, m, grid) << endl;
    return 0;
}