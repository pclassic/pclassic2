import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class q8java {

    public static int rushHourEZ(int n, int m, int[][] grid) {
        int nrow = n, ncol = m;
        int out = 0;

        for (int di = 0; di < nrow + ncol - 1; di++) {
            int r, c;
            if (di < ncol) {
                r = nrow - 1;
                c = ncol - 1 - di;
            } else {
                r = nrow - 1 - (di - ncol + 1);
                c = 0;
            }

            int stack = 0; // free moving right
            while (r >= 0 && c < ncol) { // bottom left -> top right
                if (grid[r][c] == 1) { // moving right
                    stack++;
                } else if (grid[r][c] == 2) { // moving down
                    if (stack == 0) { // no crash with stack
                        out++;
                    } else { // crash
                        stack--;
                    }
                }
                r--;
                c++;
            }
            out += stack;
        }

        return out;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        String[] dims = reader.readLine().split(" ");
        int n = Integer.parseInt(dims[0]);
        int m = Integer.parseInt(dims[1]);
        
        int[][] grid = new int[n][m];
        for (int i = 0; i < n; i++) {
            String[] row = reader.readLine().split(" ");
            for (int j = 0; j < m; j++) {
                grid[i][j] = Integer.parseInt(row[j]);
            }
        }
        
        System.out.println(rushHourEZ(n, m, grid));
    }
}
