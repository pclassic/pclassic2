#include <iostream>
#include <vector>

using namespace std;

#define f0r(i, n) for (int i = 0; i < n; i++)
using vi = vector<int>;
using vvi = vector<vi>;

int rush_hour_ez(int n, int m, const vvi& grid) {
    int nrow = n, ncol = m;
    int out = 0;

    for (int di = 0; di < nrow + ncol - 1; ++di) {
        int r, c;
        if (di < ncol) {
            r = nrow - 1;
            c = ncol - 1 - di;
        } else {
            r = nrow - 1 - (di - ncol + 1);
            c = 0;
        }

        int stack = 0; // free moving right
        while (r >= 0 && c < ncol) { // bottom left -> top right
            if (grid[r][c] == 1) { // moving right
                stack++;
            } else if (grid[r][c] == 2) { // moving down
                if (stack == 0) { // no crash with stack
                    out++;
                } else { // crash
                    stack--;
                }
            }
            --r;
            ++c;
        }
        out += stack;
    }

    return out;
}

int main() {
    cin.tie(nullptr);
    ios::sync_with_stdio(false);

    int n, m;
    cin >> n >> m;

    vvi grid(n, vi(m));
    f0r(i, n) {
        f0r(j, m) {
            cin >> grid[i][j];
        }
    }

    cout << rush_hour_ez(n, m, grid) << endl;
    return 0;
}