// C++ brute force solution using arrays (should TLE/MLE for longer test cases)

#include <iostream>
#include <vector>

#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx,avx2,fma")

using namespace std;

#define f0r(i, n) for (int i = 0; i < n; i++)
using vi = vector<int>;
using vvi = vector<vi>;

inline int rush_hour_ez(int n, int m, const vvi& grid) {
    vvi cars = grid;
    int cars_exited = 0;

    while (true) {
        bool moved = false;
        vvi new_cars(n, vi(m, 0));
        
        // right-moving
        for (int r = 0; r < n; r++) {
            for (int c = m - 1; c >= 0; c--) {
                if (cars[r][c] != 1) continue;
                
                int new_c = c + 1;
                if (new_c >= m) {
                    cars_exited++;
                } else {
                    new_cars[r][new_c] = 1;
                    moved = true;
                }
            }
        }

        // down-moving
        for (int c = 0; c < m; c++) {
            for (int r = n - 1; r >= 0; r--) {
                if (cars[r][c] != 2) continue;

                int new_r = r + 1;
                if (new_r >= n) {
                    cars_exited++;
                } else {
                    if (new_cars[new_r][c] == 1) {
                        new_cars[new_r][c] = 0;
                    } else {
                        new_cars[new_r][c] = 2;
                        moved = true;
                    }
                }
            }
        }

        if (!moved) break;
        cars = move(new_cars);
    }

    return cars_exited;
}

int main() {
    cin.tie(nullptr);
    ios::sync_with_stdio(false);

    int n, m;
    cin >> n >> m;

    vvi grid(n, vi(m));
    f0r(i, n) {
        f0r(j, m) {
            cin >> grid[i][j];
        }
    }

    cout << rush_hour_ez(n, m, grid) << endl;
    return 0;
}