# Python brute force solution using arrays (should TLE/MLE for longer test cases)

def rush_hour_ez(n, m, grid):
    cars = []
    for i in range(n):
        for j in range(m):
            if grid[i][j] == 1:  # Car moving right
                cars.append((i, j, 'right'))
            elif grid[i][j] == 2:  # Car moving down
                cars.append((i, j, 'down'))
    
    # Count the number of cars that exit the grid
    exiting_cars = 0

    # Simulate until all cars either crash or exit the grid
    while cars:
        new_cars = []
        positions = {}
        crashed_positions = set()

        # Move each car
        for i, j, direction in cars:
            if direction == 'right':
                new_i, new_j = i, j + 1
            else:  # direction == 'down'
                new_i, new_j = i + 1, j

            # Check if the car exits the grid
            if new_i >= n or new_j >= m:
                exiting_cars += 1
                continue

            # Check if this move causes a crash
            if (new_i, new_j) in positions:
                # If another car is moving to the same spot, mark a crash
                crashed_positions.add((new_i, new_j))
            else:
                # Otherwise, store the new position
                positions[(new_i, new_j)] = (new_i, new_j, direction)

        # Filter out cars that have crashed
        for pos, car in positions.items():
            if pos not in crashed_positions:
                new_cars.append(car)

        # Update the cars list for the next step
        cars = new_cars

    return exiting_cars


if __name__ == '__main__':
    n, m = map(int, input().split())
    grid = []
    for _ in range(n):
        row = list(map(int, input().split()))
        grid.append(row)

    print(rush_hour_ez(n, m, grid))