from typing import List

def rush_hour_ez(n: int, m: int, grid: List[List[int]]) -> int:
    nrow, ncol = n,m
    out = 0
    
    for di in range(nrow + ncol - 1):
        if di < ncol:   r,c = nrow-1, ncol-1-di
        else:           r,c = nrow-1-(di-ncol+1), 0
        
        stack = 0 # free moving right
        while r >= 0 and c < ncol: # bottom left -> top right
            if grid[r][c] == 1: # moving right
                stack += 1
            elif grid[r][c] == 2: # moving down
                if stack == 0: # no crash with stack
                    out += 1
                else: # crash
                    stack -= 1
            r -= 1
            c += 1
        out += stack
    
    return out

if __name__ == '__main__':
    n, m = map(int, input().split())
    grid = []
    for _ in range(n):
        row = list(map(int, input().split()))
        grid.append(row)

    print(rush_hour_ez(n, m, grid))