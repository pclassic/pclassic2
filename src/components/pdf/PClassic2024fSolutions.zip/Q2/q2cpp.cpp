#include <iostream>
#include <vector>
#include <cmath>
#include <string>
using namespace std;

void printDiffs() {
    int n;
    int k;
    cin >> n >> k;
    vector<int> diff(n);
    for (int i = 0; i < n; i++) {
        cin >> diff[i];
        diff[i] = abs(diff[i] - k);
    }
    sort(diff.begin(), diff.end());
    for (int num : diff) {
        cout << num << " ";
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    printDiffs();
    return 0;
}
