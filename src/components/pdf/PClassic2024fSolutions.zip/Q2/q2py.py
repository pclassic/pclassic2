from typing import List

def sort_abs_diff(n : int, k : int, A: List[int]) -> List[int]:
    return sorted([abs(i - k) for i in A])

if __name__ == "__main__":
    line = input().split()
    n, k = int(line[0]), int(line[1])
    A = [int(i) for i in input().split()]

    S = sort_abs_diff(n, k, A)
    print(*S)