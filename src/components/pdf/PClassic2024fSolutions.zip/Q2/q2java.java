import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q2java {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        String[] firstLine = br.readLine().split(" ");
        int n = Integer.parseInt(firstLine[0]); 
        int k = Integer.parseInt(firstLine[1]);

        String[] secondLine = br.readLine().split(" ");
        int[] differences = new int[n];
        for (int i = 0; i < n; i++) {
            int value = Integer.parseInt(secondLine[i]);
            differences[i] = Math.abs(value - k);
        }
        
        Arrays.sort(differences);

        StringBuilder result = new StringBuilder();
        for (int diff : differences) {
            result.append(diff).append(" ");
        }
        System.out.println(result.toString().trim());
    }
}