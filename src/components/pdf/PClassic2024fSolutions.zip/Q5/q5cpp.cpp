#include <iostream>
#include <vector>

using namespace std;

#define f0r(i, n) for (int i = 0; i < n; i++)
using vi = vector<int>;

int airports(int n, const vi& a) {
    int pts = 0;
    int imax = 0, pmax = a[0];
    f0r(i, n) {
        if (a[i] > pmax) { // fly here
            pts += (i-imax)*pmax;
            imax = i;
            pmax = a[i];
        }
    }
    pts += (n-1 - imax)*pmax; // leftover
    
    return pts;
}

int main() {
    int n;
    cin >> n;

    vi a(n);
    f0r(i, n) {
        cin >> a[i];
    }

    cout << airports(n, a) << endl;
    return 0;
}