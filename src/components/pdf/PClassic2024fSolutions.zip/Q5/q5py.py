from typing import List

def airports(nums: List[int]) -> int:
  ans = big = 0
  for i in nums:
    ans += big 
    big = max(i,big)
  return ans

if __name__ == '__main__':
  n = int(input())
  nums = [int(x) for x in input().split()]

  print(airports(nums))