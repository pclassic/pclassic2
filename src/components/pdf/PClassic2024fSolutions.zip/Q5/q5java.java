import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class q5java {

    public static int airports(int n, int[] a) {
        int pts = 0;
        int imax = 0, pmax = a[0];
        for (int i = 0; i < n; i++) {
            if (a[i] > pmax) { // fly here
                pts += (i-imax)*pmax;
                imax = i;
                pmax = a[i];
            }
        }
        pts += (n-1 - imax)*pmax; // leftover
        
        return pts;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        int n = Integer.parseInt(reader.readLine());

        int[] a = new int[n];
        String[] row = reader.readLine().split(" ");
        for (int i = 0; i < n; i++) {
            a[i] = Integer.parseInt(row[i]);
        }
        
        System.out.println(airports(n, a));
    }
}
