#include <bits/stdc++.h>
using namespace std;

int main() {
	int t; cin >> t;
	while (t--){
		int n; cin >> n;
		int ans = 0;
		for (int x = 2; x < n; x++){
			int curr = x;
			int same = 0;
			for (int i = 2; i*i <= x; i++){
				if (curr%i==0 && n%i==0) same++;
				while (curr%i == 0) curr/=i;
			}
			if (curr!=1 && n%curr == 0) same++;
			if (same==1) ans++;
		}
		cout << ans << "\n";
	}
}
