import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q4java {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());
        
        while (t-- > 0) {
            int n = Integer.parseInt(br.readLine());
            System.out.println(solve(n));
        }
    }
    
    public static int solve(int n) {
        int ans = 0;
        
        for (int x = 2; x < n; x++) {
            int curr = x;
            int same = 0;
            
            for (int i = 2; i <= Math.sqrt(x); i++) {
                if (n % i == 0 && curr % i == 0) same++;
                
                while (curr % i == 0) curr /= i;
            }
            
            if (curr != 1 && n % curr == 0) same++;
            
            if (same == 1) ans++;
        }

        return ans;
    }
}