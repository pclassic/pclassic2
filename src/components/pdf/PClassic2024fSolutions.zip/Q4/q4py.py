from math import isqrt
t = int(input())
for _ in range(t):
    n = int(input())
    ans = 0
    for x in range(2,n):
        curr = x
        same = 0
        for i in range(2,isqrt(x)+1):
            if n%i == 0 and curr%i==0: same+=1
            while curr%i==0: curr//=i
        if curr != 1 and n%curr==0: same+=1
        if same == 1: ans+=1
    print(ans)
