import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.Deque;

public class q9java {

    public static int rushHour(int n, int m, int[][] grid) {
        int nrow = n, ncol = m;
        int[] rowCrash = new int[nrow]; // earliest col of crash per row
        int[] colCrash = new int[ncol]; // earliest row of crash per col

        for (int i = 0; i < nrow; i++) rowCrash[i] = ncol;
        for (int i = 0; i < ncol; i++) colCrash[i] = nrow;

        int out = 0;

        for (int di = 0; di < nrow + ncol - 1; di++) {
            int r, c;
            if (di < ncol) {
                r = nrow - 1;
                c = ncol - 1 - di;
            } else {
                r = nrow - 1 - (di - ncol + 1);
                c = 0;
            }

            Deque<Integer> deque = new ArrayDeque<>(); // free moving right
            int nfree = 0; // will exit grid
            while (r >= 0 && c < ncol) { // bottom left -> top right
                if (grid[r][c] == 1) { // moving right
                    deque.push(r);
                    if (rowCrash[r] == ncol) { // won't crash with an existing crash
                        nfree++;
                    }
                } else if (grid[r][c] == 2) { // moving down
                    if (deque.isEmpty()) { // no crash with deque
                        if (colCrash[c] == nrow) { // won't crash with an existing crash
                            nfree++;
                        }
                    } else { // crash
                        // find first row that doesn't crash before reaching this col
                        while (!deque.isEmpty() && rowCrash[deque.peek()] < c) {
                            deque.pop();
                        }

                        if (deque.isEmpty()) { // all others crashed early
                            if (colCrash[c] == nrow) { // won't crash with an existing crash
                                nfree++;
                            }
                        } else {
                            int crashRow = deque.pop(); // closest crash row
                            if (colCrash[c] < crashRow) { // this col will crash before reaching crash row
                                deque.push(crashRow);
                            } else { // will crash with popped row
                                if (rowCrash[crashRow] == ncol) { // would have been free, but crashed
                                    nfree--;
                                }
                                rowCrash[crashRow] = c;
                                colCrash[c] = crashRow;
                            }
                        }
                    }
                }
                r--;
                c++;
            }
            out += nfree;
        }

        return out;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        String[] dims = reader.readLine().split(" ");
        int n = Integer.parseInt(dims[0]);
        int m = Integer.parseInt(dims[1]);
        
        int[][] grid = new int[n][m];
        for (int i = 0; i < n; i++) {
            String[] row = reader.readLine().split(" ");
            for (int j = 0; j < m; j++) {
                grid[i][j] = Integer.parseInt(row[j]);
            }
        }
        
        System.out.println(rushHour(n, m, grid));
    }
}
