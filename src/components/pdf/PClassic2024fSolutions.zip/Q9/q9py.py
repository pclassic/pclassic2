from typing import List

def rush_hour(n: int, m: int, grid: List[List[int]]) -> int:
    nrow, ncol = n,m
    row_crash = [ncol]*nrow # earliest col of crash per row
    col_crash = [nrow]*ncol # earliest row of crash per col
    out = 0
    
    for di in range(nrow + ncol - 1):
        if di < ncol:   r,c = nrow-1, ncol-1-di
        else:           r,c = nrow-1-(di-ncol+1), 0
        
        stack = [] # free moving right
        nfree = 0 # will exit grid
        while r >= 0 and c < ncol: # bottom left -> top right
            if grid[r][c] == 1: # moving right
                stack.append(r)
                if row_crash[r] == ncol: # won't crash with an existing crash
                    nfree += 1
            elif grid[r][c] == 2: # moving down
                if len(stack) == 0: # no crash with stack
                    if col_crash[c] == nrow: # won't crash with an existing crash
                        nfree += 1
                else: # crash
                    # find first row that doesn't crash before reaching this col
                    while stack and row_crash[stack[-1]] < c:
                        stack.pop()

                    if not stack: # all others crashed early
                        if col_crash[c] == nrow: # won't crash with an existing crash
                            nfree += 1
                    else:
                        crash_r = stack.pop() # closest crash row
                        if col_crash[c] < crash_r: # this col will crash before reaching crash row
                            stack.append(crash_r)
                        else: # will crash with popped row
                            if row_crash[crash_r] == ncol: # would have been free, but crashed
                                nfree -= 1
                            row_crash[crash_r] = c
                            col_crash[c] = crash_r
            r -= 1
            c += 1
        out += nfree
    
    return out

if __name__ == '__main__':
    n, m = map(int, input().split())
    grid = []
    for _ in range(n):
        row = list(map(int, input().split()))
        grid.append(row)

    print(rush_hour(n, m, grid))