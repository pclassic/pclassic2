#include <iostream>
#include <vector>
#include <stack>

using namespace std;

#define f0r(i, n) for (int i = 0; i < n; i++)
using vi = vector<int>;
using vvi = vector<vi>;

int rush_hour(int n, int m, const vvi& grid) {
    int nrow = n, ncol = m;
    vi row_crash(nrow, ncol); // earliest col of crash per row
    vi col_crash(ncol, nrow); // earliest row of crash per col
    int out = 0;

    for (int di = 0; di < nrow + ncol - 1; ++di) {
        int r, c;
        if (di < ncol) {
            r = nrow - 1;
            c = ncol - 1 - di;
        } else {
            r = nrow - 1 - (di - ncol + 1);
            c = 0;
        }

        stack<int> stack; // free moving right
        int nfree = 0; // will exit grid
        while (r >= 0 && c < ncol) { // bottom left -> top right
            if (grid[r][c] == 1) { // moving right
                stack.push(r);
                if (row_crash[r] == ncol) { // won't crash with an existing crash
                    ++nfree;
                }
            } else if (grid[r][c] == 2) { // moving down
                if (stack.empty()) { // no crash with stack
                    if (col_crash[c] == nrow) { // won't crash with an existing crash
                        ++nfree;
                    }
                } else { // crash
                    // find first row that doesn't crash before reaching this col
                    while (!stack.empty() && row_crash[stack.top()] < c) {
                        stack.pop();
                    }

                    if (stack.empty()) { // all others crashed early
                        if (col_crash[c] == nrow) { // won't crash with an existing crash
                            ++nfree;
                        }
                    } else {
                        int crash_r = stack.top();
                        stack.pop();
                        if (col_crash[c] < crash_r) { // this col will crash before reaching crash row
                            stack.push(crash_r);
                        } else { // will crash with popped row
                            if (row_crash[crash_r] == ncol) { // would have been free, but crashed
                                --nfree;
                            }
                            row_crash[crash_r] = c;
                            col_crash[c] = crash_r;
                        }
                    }
                }
            }
            --r;
            ++c;
        }
        out += nfree;
    }

    return out;
}

int main() {
    cin.tie(nullptr);
    ios::sync_with_stdio(false);

    int n, m;
    cin >> n >> m;

    vvi grid(n, vi(m));
    f0r(i, n) {
        f0r(j, m) {
            cin >> grid[i][j];
        }
    }

    cout << rush_hour(n, m, grid) << endl;
    return 0;
}