# Python brute force solution using arrays (should TLE/MLE for longer test cases)

def print_grid(n, m, car_positions, crash_grid):
    # Create a display grid
    display_grid = [['.' for _ in range(m)] for _ in range(n)]
    
    # Place crashes
    for i in range(n):
        for j in range(m):
            if crash_grid[i][j]:
                display_grid[i][j] = 'X'
    
    # Place cars
    for i, j, direction in car_positions:
        if not crash_grid[i][j]:  # Only display if it's not a crash site
            display_grid[i][j] = '>' if direction == 'right' else 'v'
    
    # Print the display grid
    # for row in display_grid:
    #     print(''.join(row))
    # print()  # Blank line between steps

def rush_hour(n, m, grid):
    # Create a crash grid to track crash sites
    crash_grid = [[False] * m for _ in range(n)]
    # Track cars and their positions and directions
    cars = []
    for i in range(n):
        for j in range(m):
            if grid[i][j] == 1:  # Car moving right
                cars.append((i, j, 'right'))
            elif grid[i][j] == 2:  # Car moving down
                cars.append((i, j, 'down'))
                
    # Initialize count for cars that exit the grid
    exiting_cars = 0

    # Simulate car movements until no cars can move
    step = 0
    while cars:
        print(f"Step {step}:")
        print_grid(n, m, cars, crash_grid)
        
        new_cars = []
        positions = {}
        
        # Move each car
        for i, j, direction in cars:
            if direction == 'right':
                new_i, new_j = i, j + 1
            else:  # direction == 'down'
                new_i, new_j = i + 1, j
            
            # Check if the car is exiting the grid
            if new_i >= n or new_j >= m:
                exiting_cars += 1
                continue
            
            # Check for a crash or mark new position
            if crash_grid[new_i][new_j]:
                continue  # Car crashes if it moves to a crash site
            
            # Track positions for crash detection
            if (new_i, new_j) in positions:
                # If another car is here, it’s a crash
                crash_grid[new_i][new_j] = True
            else:
                # Otherwise, store this car's position to check for crashes
                positions[(new_i, new_j)] = (new_i, new_j, direction)
                new_cars.append((new_i, new_j, direction))
        
        print(f"{exiting_cars=}")
        
        # Update the cars list with those that haven’t exited or crashed
        cars = [car for car in new_cars if not crash_grid[car[0]][car[1]]]
        step += 1

    # Final print of the grid state after simulation
    print("Final State:")
    print_grid(n, m, [], crash_grid)
    
    return exiting_cars


if __name__ == '__main__':
    n, m = map(int, input().split())
    grid = []
    for _ in range(n):
        row = list(map(int, input().split()))
        grid.append(row)

    print(rush_hour(n, m, grid))