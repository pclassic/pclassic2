#include <iostream>
#include <vector>
#include <cmath>
#include <string>
using namespace std;

void printSubstrs() {
    string s;
    int k;
    cin >> k;
    cin >> s;
    for (int i = s.length(); i > 0; i--) {
        cout << s.substr(0, i) << endl;
    }
}

int main() {
    ios::sync_with_stdio(false);
	cin.tie(NULL);
    printSubstrs();
    return 0;
}