def print_prefixes(k : int, s : str) -> None:
    for i in range(k):
        print(s[:k-i])

if __name__ == '__main__':
    k = int(input())
    s = input()

    print_prefixes(k, s)