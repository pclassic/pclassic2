import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q1java {

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int k = Integer.parseInt(br.readLine());
        String s = br.readLine();
        printSubstrs(s, k);
    }

    public static void printSubstrs(String s, int k) {
        for (int i = s.length(); i >= 0; i--) {
            System.out.println(s.substring(0, i));
        }
    }
}