import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class q6java {

    public static long bad_nums(long k, long[] bad) {
        long ans = k*(k+1) / 2;
    
        for (long i : bad) {
            if (i > ans) continue;
            long x = (long) Math.sqrt(8*i+1);
            if (x*x == 8*i+1 && x%2 == 1) { // triangular num
                long n = (x-1)/2;
                ans = n*(n-1)/2;
            }
        }
        
        return ans;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        String[] nk = reader.readLine().split(" ");
        int n = Integer.parseInt(nk[0]);
        int k = Integer.parseInt(nk[1]);

        long[] bad = new long[n];
        String[] line = reader.readLine().split(" ");
        for (int i = 0; i < n; i++) {
            bad[i] = Long.parseLong(line[i]);
        }
        
        System.out.println(bad_nums((long) k, bad));
    }
}
