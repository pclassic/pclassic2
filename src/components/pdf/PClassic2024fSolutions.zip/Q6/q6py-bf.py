# Python brute force solution (should TLE for longer test cases)

from typing import List

def bad_nums(k: int, bad: List[int]) -> int:
    avoid = set()
    max_pos = k * (k + 1) // 2
    for i in bad:
        if i > max_pos: continue
        avoid.add(i)

    pos = 0
    step = 1
    while step <= k:
        if pos + step in avoid: break
        pos += step
        step += 1

    return pos

if __name__ == "__main__":
    n, k = map(int, input().split())
    bad = list(map(int, input().strip().split()))
    
    print(bad_nums(k, bad))