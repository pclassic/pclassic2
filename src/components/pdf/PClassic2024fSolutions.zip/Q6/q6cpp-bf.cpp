// C++ brute force solution (should TLE for longer test cases)

#include <iostream>
#include <vector>
#include <unordered_set>

using namespace std;

using llong = long long;
using vll = vector<llong>;
#define f0r(i, n) for (llong i = 0; i < n; i++)

llong bad_nums(llong k, const vll& bad) {
    unordered_set<llong> avoid;
    llong max_pos = k*(k+1) / 2;
    
    for (llong i : bad) {
        if (i > max_pos) continue;
        avoid.insert(i);
    }

    llong pos = 0;
    llong step = 1;
    while (step <= k) {
        if (avoid.find(pos + step) != avoid.end()) break;
        pos += step;
        step++;
    }

    return pos;
}

int main() {
    int n, k;
    cin >> n >> k;

    vll bad(n);
    f0r(i,n) {
        cin >> bad[i];
    }

    cout << bad_nums(k, bad) << endl;
    
    return 0;
}
