#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

using llong = long long;
using vll = vector<llong>;
#define f0r(i, n) for (llong i = 0; i < n; i++)

llong bad_nums(llong k, const vll& bad) {
    llong ans = k*(k+1) / 2;
    
    for (llong i : bad) {
        if (i > ans) continue;
        llong x = static_cast<llong>(sqrt(8*i+1));
        if (x*x == 8*i+1 && x%2) { // triangular num
            llong n = (x-1)/2;
            ans = n*(n-1)/2;
        }
    }
    
    return ans;
}

int main() {
    int n, k;
    cin >> n >> k;
    
    vll bad(n);
    f0r(i,n) {
        cin >> bad[i];
    }
    
    cout << bad_nums(k, bad) << endl;
    
    return 0;
}
