from typing import List
from math import isqrt

def bad_nums(k: int, bad: List[int]) -> int:
    ans = k*(k+1) // 2
    for i in bad:
        if i > ans: continue
        x = isqrt(8*i+1)
        if x*x == 8*i+1 and x%2: # triangular num
            n = (x-1)//2
            ans = n*(n-1)//2
    return ans

if __name__ == '__main__':
    n, k = map(int, input().split())
    bad = list(map(int, input().split()))
    
    print(bad_nums(k, bad))