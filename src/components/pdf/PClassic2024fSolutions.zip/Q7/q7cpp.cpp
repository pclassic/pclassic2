#include <iostream>
#include <vector>

using namespace std;

#define f0r(i, n) for (int i = 0; i < n; i++)
#define MAX(a, b) ((a) > (b) ? (a) : (b))
using llong = long long;
using vll = vector<llong>;

bool ok_start(llong spd0, const vll& barns) {
    llong max_spd = spd0;
    llong spd = spd0;
    bool doubled = false;

    for (llong ds : barns) {
        spd += ds;
        if (spd <= 0) {
            spd += max_spd; // try to use spd boost at max spd thus far
            if (doubled || spd <= 0) return false; // already boosted or not enough spd
            doubled = true;
        }
        max_spd = MAX(max_spd, spd);
    }

    return (spd > 0);
}

llong bessie(int n, const vll& barns) {
    llong min_spd = 1;
    while (!ok_start(min_spd, barns)) {
        if (min_spd > numeric_limits<llong>::max() / 2) { // would overflow
            min_spd = numeric_limits<llong>::max();
            break;
        }
        min_spd *= 2;
    }

    llong lo = min_spd / 2;
    llong hi = min_spd;
    while (lo <= hi) {
        llong mid = (lo+hi) / 2;
        if (ok_start(mid, barns)) { // search left
            min_spd = mid;
            hi = mid-1;
        } else { // search right
            lo = mid+1;
        }
    }

    return MAX(1, min_spd);
}

int main() {
    int n;
    cin >> n;

    vll barns(n);
    f0r(i, n) {
        cin >> barns[i];
    }

    cout << bessie(n, barns) << endl;
    return 0;
}