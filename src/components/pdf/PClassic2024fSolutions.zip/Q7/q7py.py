n = int(input())
nums = [int(x) for x in input().split()]
def check(x):
	big = curr = x
	used = False
	for i in nums:
		if curr+i <= 0:
			if used or big+curr+i <= 0: return False
			curr+=big+i
			used = True
		else: curr+=i
		big = max(curr,big)
	return curr > 0

lo = 1
hi = 10**18
ans = 10**18
while lo <= hi:
	mid = (lo+hi)//2
	if check(mid):
		ans = mid
		hi = mid-1
	else:
		lo = mid+1
print(ans)
