import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class q7java {

    public static boolean ok_start(long spd0, long[] barns) {
        long spd = spd0;
        long maxSpd = spd;
        boolean doubled = false;

        for (long ds : barns) {
            spd += ds;
            if (spd <= 0) {
                spd += maxSpd; // try to use speed boost at max speed thus far
                if (doubled || spd <= 0) return false; // already boosted or not enough speed
                doubled = true;
            }
            maxSpd = Math.max(maxSpd, spd);
        }

        return spd > 0;
    }

    public static long bessie(int n, long[] barns) {
        long lo = 1;
        long hi = (long) 1e18;
        long minSpd = hi;

        while (lo <= hi) {
            long mid = (lo+hi) / 2;
            if (ok_start(mid, barns)) { // search left
                minSpd = mid;
                hi = mid-1;
            } else { // search right
                lo = mid+1;
            }
        }

        return Math.max(1, minSpd);
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        int n = Integer.parseInt(reader.readLine());

        long[] barns = new long[n];
        String[] line = reader.readLine().split(" ");
        for (int i = 0; i < n; i++) {
            barns[i] = Long.parseLong(line[i]);
        }

        System.out.println(bessie(n, barns));
    }
}
