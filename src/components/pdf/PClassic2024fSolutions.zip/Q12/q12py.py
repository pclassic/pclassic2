from math import sqrt
n, P = map(int, input().strip().split())
L, H = [0]*n, [0]*n
ans = 0
for i in range(n):
    L[i], H[i] = map(int, input().strip().split())
diff = P-2*(sum(L) + sum(H))
S = [[0, 0]]
for i in range(n):
    nex = []
    for x in S:
        if diff < x[0]+2*min(L[i], H[i]):
            break
        nex.append([x[0]+2*min(L[i], H[i]), x[1]+2*sqrt(L[i]**2 + H[i]**2)])
    result = []
    i = j = 0
    while i < len(S) or j < len(nex):
        interval = None
        if j == len(nex) or (i < len(S) and S[i][0] < nex[j][0]):
            interval = S[i]
            i += 1
        else:
            interval = nex[j]
            j += 1
        if not result or result[-1][1] < interval[0]:
            result.append(list(interval))
        else:
            result[-1][1] = max(result[-1][1], interval[1])
    S = [x for x in result]
print(P-max(0, diff-S[-1][1]))

