from math import isqrt,gcd
n,k = map(int,input().split())
nums = [int(x) for x in input().split()]
tree = [0]*(2*n)
for i in range(n) :
    tree[n + i] = nums[i]
for i in range(n - 1, 0, -1) :
    tree[i] = gcd(tree[2*i],tree[2*i+1])
def query(l, r) :
    ans = 0
    l += n
    r += n
    while l < r:
        if (l & 1):
            ans =gcd(ans,tree[l])
            l += 1
        if (r & 1):
            r-=1
            ans =gcd(ans,tree[r])
        l //= 2
        r //= 2
    return ans
ans = 0
hi = -1
factors = []
for x in nums:
    curr = {}
    for i in range(2,isqrt(x)+1):
        if x%i == 0:
            curr[i]=0
        while x%i==0:
            curr[i]+=1
            x//=i
    if x!=1: curr[x]=1
    factors.append(curr)
curr = {}
for lo in range(n):
    while len(curr)<=k and hi < n-1:
        hi+=1
        for x in factors[hi]:
            if x not in curr: curr[x]=factors[hi][x]
            else: curr[x]+=factors[hi][x]
    if hi == lo:
        curr = {}
        continue
    if len(curr)>k:
        for x in factors[hi]:
            curr[x]-=factors[hi][x]
            if curr[x]==0: del curr[x]
        hi -=1
    if len(curr)==k and query(lo,hi+1)==1: ans = max(ans,hi-lo+1)
    for x in factors[lo]:
        curr[x]-=factors[lo][x]
        if curr[x]==0: del curr[x]
print(ans)
