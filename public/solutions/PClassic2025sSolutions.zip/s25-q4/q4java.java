import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q4java {
    public static int calculate(int n, String s) {
        int result = 0;
        Character operand = null;
        
        for (int i = 0; i < s.length(); i++) {
            char x = s.charAt(i);
            if (Character.isDigit(x)) {
                if (operand == null) {
                    result = Character.getNumericValue(x);
                } else {
                    switch (operand) {
                        case '+':
                            result += Character.getNumericValue(x);
                            break;
                        case '-':
                            result -= Character.getNumericValue(x);
                            break;
                        case '*':
                            result *= Character.getNumericValue(x);
                            break;
                        case '$':
                            result = result * Character.getNumericValue(x) - result - Character.getNumericValue(x);
                            break;
                    }
                }
            } else {
                operand = x;
            }
        }

        return result;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String s = br.readLine();

        System.out.println(calculate(n, s));
    }
}
