def q4solver(n, s):
    result = 0
    operand = None
    for x in s:
        if x.isdigit():
            if operand is None:
                result = int(x)
            else:
                if operand == '+':
                    result += int(x)
                elif operand == '-':
                    result -= int(x)
                elif operand == '*':
                    result *= int(x)
                elif operand == '$':
                    result = result * int(x) - result - int(x)
        else:
            operand = x

    print(result)

if __name__ == '__main__':
    n = int(input())
    s = input()

    q4solver(n, s)
