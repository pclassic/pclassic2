#include <iostream>
#include <cctype>

using namespace std;

int compute_one(int ans, string accum, char op) {
    int b = stoi(accum);
    switch (op) {
        case '+':
            return ans + b;
        case '-':
            return ans - b;
        case '*':
            return ans * b;
        case '$':
            return ans * b - ans - b;
    }
    return 0;
}

int main () {
    int n;
    string s;
    cin >> n >> s;

    int ans = 0;
    string accum;
    char op = '+';
    for (int i = 0; i < n; i++) {
        if (isdigit(s.at(i))) {
            accum.push_back(s.at(i));
            continue;
        }
        int operand = stoi(accum);
        ans = compute_one(ans, accum, op);
        op = s.at(i);
        accum.clear();
    }

    ans = compute_one(ans, accum, op);
    cout << ans << endl;
    return 0;
}