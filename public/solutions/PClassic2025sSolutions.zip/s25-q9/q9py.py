from math import isqrt
mod = 10**9+7
big = 10000000
sieve = [1]*(big+1)
for i in range(2,isqrt(big+1)+1):
    if sieve[i]:
        for j in range(i*i, big+1,i):
            sieve[j]=0
primes = [i for i in range(2,big+1) if sieve[i]]
for _ in range(int(input())):
    n = int(input())
    ans = 1
    for x in primes:
        if x > n: break
        curr = x
        count = 0
        while curr <= n:
            val = (n-curr)//curr
            val = (val)*(val+1)//2
            val = (val*curr)%mod
            val = (val+ ((n%curr)+1)*(n//curr))%mod
            count = (count+val)%mod
            curr*=x
        ans *= count+1
        ans%=mod
    print(ans)

