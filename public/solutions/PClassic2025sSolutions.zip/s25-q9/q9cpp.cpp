// Source: https://usaco.guide/general/io

#include <bits/stdc++.h>
using namespace std;
#define int long long
#define vt vector
int calc(int n, int x) {
    /*
    x to 2x-1: +1
    2x to 3x-1: +2
    ...
    floor(n/x) * x to n: +floor(n/x)
    */
    /*
    find 1+2+...+floor(n/x)-1
    */
    int flr = n/x;
    int ans = x*(flr-1)*flr/2;
    int last = n-(n/x*x)+1;
    ans+=flr*last;
    return ans;
}
signed main() {
    ios_base::sync_with_stdio(false); 
    cin.tie(0);
    // freopen("input.txt" , "r" , stdin);
    // freopen("output.txt" , "w", stdout);
    // cout << calc(10,3) << endl;
    int t = 1;
    cin >> t;
    vt<bool> prime(10000005, 1);
    prime[1]=0;
    for(int i = 2; i < 10000005; i++) {
        if(!prime[i]) continue;
        for(int j = i*i; j < 10000005; j+=i) {
            prime[j]=false;
        }
    }
    while(t--) {
        int n;
        cin >> n;
        int ans = 1;
        for(int i = 2; i <= n; i++) {
            if(!prime[i]) continue;
            int here = 1, mul = i;
            while(mul<=n) {
                here+=calc(n,mul);
                here%=1000000007;
                mul*=i;
                // cout << "LINE 183 " << here << endl;
            }
            // cout << i << " " << here << endl;
            ans*=here;
            ans%=1000000007;
        }    
        cout << ans << endl;
    }
    return 0;
}