#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<ll, ll> pii;

template<class T>
struct RMQ {
	vector<vector<T>> jmp;
	RMQ(const vector<T>& V) : jmp(1, V) {
		for (int pw = 1, k = 1; pw * 2 <= sz(V); pw *= 2, ++k) {
			jmp.emplace_back(sz(V) - pw * 2 + 1);
			rep(j,0,sz(jmp[k]))
				jmp[k][j] = min(jmp[k - 1][j], jmp[k - 1][j + pw]);
		}
	}
	T query(int a, int b) {
		assert(a < b); // or return inf if a == b
		int dep = 31 - __builtin_clz(b - a);
		return min(jmp[dep][a], jmp[dep][b - (1 << dep)]);
	}
};

struct LCA {
	int T = 0;
	vi time, path, ret, depth, length;
	RMQ<ll> rmq;

	LCA(vector<vector<pii>> &C) : time(sz(C)), depth(sz(C)), length(sz(C)), rmq((dfs(C, 0, -1), ret)) {}
	void dfs(vector<vector<pii>> &C, int v, int par) {
		time[v] = T++;
		for (auto [y, w] : C[v])
			if (y != par) {
				path.push_back(v), ret.push_back(time[v]);
				depth[y] = depth[v]+1;
				length[y] = length[v]+w;
				dfs(C, y, v);
			}
	}

	int lca(int a, int b) {
		if (a == b)
			return a;
		tie(a, b) = minmax(time[a], time[b]);
		return path[rmq.query(a, b)];
	}
	ll dist(int a, int b) { return depth[a] + depth[b] - 2 * depth[lca(a, b)]; }
	ll wdist(int a, int b) { return length[a] + length[b] - 2 * length[lca(a, b)]; }
};

struct Tree {
	typedef pii T;
	static constexpr T unit = {0, 0};
	T f(T a, T b) { return {a.F+b.F, a.S+b.S}; }
	vector<T> s; int n;
	Tree(int n = 0, T def = unit) : s(2*n, def), n(n) {}
	void update(int pos, T val) {
		for (s[pos += n] = val; pos /= 2;)
			s[pos] = f(s[pos * 2], s[pos * 2 + 1]);
	}
	T query(int b, int e) { // query [b, e)
		T ra = unit, rb = unit;
		for (b += n, e += n; b < e; b /= 2, e /= 2) {
			if (b % 2) ra = f(ra, s[b++]);
			if (e % 2) rb = f(s[--e], rb);
		}
		return f(ra, rb);
	}
};

void solve() {
	int n, q;
	cin >> n >> q;
	vector<vector<pii>> adj(n);
	for (int i = 0; i < n - 1; i++) {
		int u, v, w;
		cin >> u >> v >> w;
		u--;
		v--;
		adj[u].pb({v, w});
		adj[v].pb({u, w});
	}
	vector<pii> qu(q);
	for (int i = 0; i < q; i++) {
		int s, t;
		cin >> s >> t;
		s--;
		t--;
		qu[i] = {s, t};
	}

	std::cout << std::fixed << std::setprecision(10);

	LCA lca(adj);

	set<array<ll,3>> edge_set;
	function<void(int,int)> dfs1 = [&](int u, int p) {
		for(auto [v, w] : adj[u]) if(v != p) {
			edge_set.insert({w, u, v});
			dfs1(v, u);
		}
	};
	dfs1(0, -1);

	vector<array<ll,3>> edges(all(edge_set));

	int i = 0;
	map<pii, int> edge_index;
	for(auto [w, u, v] : edges) {
		edge_index[{u, v}] = i++;
	}

	vector<vector<pair<double,pair<int,int>>>> updates(n);
	for(int i = 0; i < q; i++) {
		auto [s, t] = qu[i];
		ll a = lca.lca(s, t);
		ll dist = lca.wdist(s, t);
		ll len = lca.dist(s, t);
		double avg = ((double)dist)/len;
		updates[s].pb({avg, {i, 1}});
		updates[t].pb({avg, {i, 1}});
		updates[a].pb({avg, {i, -2}});
	}

	vector<double> ans(q);
	Tree cur_edges(n-1);
	function<void(int,int)> dfs2 = [&](int u, int p) {
		for(auto [avg, upd] : updates[u]) {
			auto [i, mult] = upd;
			ll uw = (ll)ceil(avg);
			int ei = lower_bound(all(edges), array<ll,3>{uw, 0, 0}) - begin(edges);
			// cerr << avg << ": " << ei << "!" << nl;
			auto [lcnt, lsum] = cur_edges.query(0, ei); 
			ans[i] += mult * (lcnt * avg - lsum);
			auto [rcnt, rsum] = cur_edges.query(ei, n-1); 
			ans[i] += mult * (rsum - rcnt * avg);
		}
		for(auto [v, w] : adj[u]) if(v != p) {
			int ei = edge_index[{u,v}];
			cur_edges.update(ei, {1, w});
			dfs2(v, u);
			cur_edges.update(ei, {0, 0});
		}
	};
	dfs2(0, -1);

	for(int i = 0; i < q; i++) {
		auto [s, t] = qu[i];
		ll len = lca.dist(s, t);
		ans[i] /= len;
	}

	for(int i = 0; i < q; i++) {
		cout << ans[i] << nl;
	}
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	solve();
	return 0;
}