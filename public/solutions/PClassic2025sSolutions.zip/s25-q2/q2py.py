def flappy(grid):
    n = len(grid)
    m = len(grid[0])

    lst_top = -1
    fst_bot = n

    for r in range(n):
        for c in range(m):
            if grid[r][c] == 1:
                lst_top = max(lst_top, r)
            elif grid[r][c] == 2:
                fst_bot = min(fst_bot, r)

    gap = fst_bot - lst_top - 1
    return max(0, gap)

if __name__ == '__main__':
    n, m = map(int, input().split())
    grid = [list(map(int, input().split())) for _ in range(n)]

    print(flappy(grid))