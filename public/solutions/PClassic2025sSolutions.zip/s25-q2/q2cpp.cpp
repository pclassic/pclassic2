#include <iostream>
#include <vector>

using namespace std;

using vi = vector<int>;
using vvi = vector<vi>;
#define f0r(i, n) for (int i = 0; i < n; i++)

int flappy(const vvi& grid) {
  int n = grid.size();
  int m = grid[0].size();

  int lst_top = -1;
  int fst_bot = n;

  for (int r = 0; r < n; r++) {
    for (int c = 0; c < m; c++) {
      if (grid[r][c] == 1) {
        lst_top = max(lst_top, r);
      } else if (grid[r][c] == 2) {
        fst_bot = min(fst_bot, r);
      }
    }
  }

  int gap = fst_bot - lst_top - 1;
  return max(0, gap); // 0 if no gap
}

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  
  int n, m;
  cin >> n >> m;

  vvi grid(n, vi(m));
  f0r(i, n) {
    f0r(j, m) {
      cin >> grid[i][j];
    }
  }

  cout << flappy(grid) << endl;
  return 0;
}