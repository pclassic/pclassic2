import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q2java {

    public static int getMinDifference(int[][] map, int n, int m) {
        int maxTop = 0;
        int minBottom = n;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (map[i][j] == 1 && i + 1 > maxTop) maxTop = i + 1;

                if (map[i][j] == 2 && i < minBottom) minBottom = i;
            }
        }

        return Math.max(minBottom - maxTop, 0);
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        String dimension = br.readLine();
        String[] parts = dimension.trim().split("\\s+");
        int n = Integer.parseInt(parts[0]);
        int m = Integer.parseInt(parts[1]);

        int[][] map = new int[n][m];

        for (int i = 0; i < n; i++) {
            String[] currLine = br.readLine().trim().split("\\s+");

            for (int j = 0; j < m; j++) {
                map[i][j] = Integer.parseInt(currLine[j]);
            }
        }

        System.out.println(getMinDifference(map, n, m));
    }
}