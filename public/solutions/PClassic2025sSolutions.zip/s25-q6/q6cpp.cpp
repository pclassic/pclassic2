#include <iostream>
#include <vector>
#include <unordered_map>
#include <ostream>

using namespace std;

int main () {

    int n, m;

    cin >> n >> m;
    vector<int> vertical_lines(m);
    vector<int> horizontal_lines(n);

    for (int i = 0; i < n; i++) {
        cin >> horizontal_lines[i];
    }

    for (int i = 0; i < m; i++) {
        cin >> vertical_lines[i];
    }

    // pairwise differences for horizontal lines
    unordered_map<int, int> horizontal_lengths;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            horizontal_lengths[abs(horizontal_lines[i] - horizontal_lines[j])]++; // Use [] to insert and increment
        }
    }

    // check for matching lengths in vertical lines
    int square_count = 0;
    for (int i = 0; i < m; i++) {
        for (int j = i + 1; j < m; j++) {
            int length = abs(vertical_lines[i] - vertical_lines[j]);
            if (horizontal_lengths.find(length) != horizontal_lengths.end()) {
                square_count += horizontal_lengths[length];
            }
        }
    }

    cout << square_count << endl;
    return 0;
}