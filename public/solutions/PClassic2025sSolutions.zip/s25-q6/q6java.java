import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class q6java {
    
    public static Map<Integer, Integer> getDistanceCounts(int[] coords) {
        Arrays.sort(coords);
        Map<Integer, Integer> distCounts = new HashMap<>();
        int n = coords.length;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                int dist = coords[j] - coords[i];
                distCounts.put(dist, distCounts.getOrDefault(dist, 0) + 1);
            }
        }
        return distCounts;
    }

    public static int numberOfSquares(int[] xCoord, int[] yCoord) {
        Map<Integer, Integer> xDists = getDistanceCounts(xCoord);
        Map<Integer, Integer> yDists = getDistanceCounts(yCoord);
        
        int total = 0;
        for (Map.Entry<Integer, Integer> xEntry : xDists.entrySet()) {
            int dist = xEntry.getKey();
            if (yDists.containsKey(dist)) {
                total += xEntry.getValue() * yDists.get(dist);
            }
        }
        return total;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] parts = br.readLine().trim().split("\\s+");
        int n = Integer.parseInt(parts[0]);
        int m = Integer.parseInt(parts[1]);

        int[] yCoord = new int[n];
        int[] xCoord = new int[m];

        // Read y-coordinates
        String[] yCoordArr = br.readLine().trim().split("\\s+");
        for (int i = 0; i < n; i++) {
            yCoord[i] = Integer.parseInt(yCoordArr[i]);
        }
        
        // Read x-coordinates
        String[] xCoordArr = br.readLine().trim().split("\\s+");
        for (int i = 0; i < m; i++) {
            xCoord[i] = Integer.parseInt(xCoordArr[i]);
        }

        System.out.println(numberOfSquares(xCoord, yCoord));
    }
}