from collections import Counter

def get_dists(coords):
    coords.sort()
    dists = Counter()
    n = len(coords)
    for i in range(n):
        for j in range(i+1, n):
            dists[coords[j] - coords[i]] += 1
    return dists

if __name__ == "__main__":
    n, m = map(int, input().split())
    ys = list(map(int, input().split()))
    xs = list(map(int, input().split()))

    dys = get_dists(ys)
    dxs = get_dists(xs)
    
    nsquares = 0
    for dy in dys:
        if dy in dxs:
            nsquares += dys[dy] * dxs[dy]

    print(nsquares)