#include <bits/stdc++.h>
using namespace std;

int count_pclassic(const string& s) {
  unordered_set<char> pclassic = {'p', 'c', 'l', 'a', 's', 'i'};
  int cnt = 0;
  for (char c : s) {
    if (pclassic.count(c)) {
      cnt++;
    }
  }
  return cnt;
}

int main() {
  int n;
  string s;
  cin >> n >> s;
  
  cout << count_pclassic(s) << endl;

  return 0;
}
