import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q1java {

    public static int countOccurrencePClassic(int n, String s) {
        int count = 0;

        for (int i = 0; i < n; i++) {
            if (s.charAt(i) == 'p' || s.charAt(i) == 'c' || s.charAt(i) == 'l' ||
                s.charAt(i) == 'a' || s.charAt(i) == 's' || s.charAt(i) == 'i') {
                    count += 1;
                }
        }

        return count;
    }
    
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String s = br.readLine();
        
        System.out.println(countOccurrencePClassic(n, s));
    }
}