def q1solver(n, s):
    count = 0
    for char in s:
        if char in "pclassic":
            count += 1
    print(count)


if __name__ == '__main__':
    n = int(input())
    s = input()

    q1solver(n, s)