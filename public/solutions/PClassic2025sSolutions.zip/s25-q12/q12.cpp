#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<int, int> pii;

vi pi(const string &s) {
	vi p(sz(s));
	rep(i, 1, sz(s)) {
		int g = p[i - 1];
		while (g && s[i] != s[g])
			g = p[g - 1];
		p[i] = g + (s[i] == s[g]);
	}
	return p;
}

struct FT {
	vector<ll> s;
	FT(int n) : s(n) {}
	void update(int pos, ll dif) { // a[pos] += dif
		for (; pos < sz(s); pos |= pos + 1)
			s[pos] += dif;
	}
	ll query(int pos) { // sum of values in [0, pos)
		ll res = 0;
		for (; pos > 0; pos &= pos - 1)
			res += s[pos - 1];
		return res;
	}
	ll range(int l, int r) { // sum of values in [l, r]
		return query(r + 1) - query(l);
	}
};

vector<vi> treeJump(vi &P) {
	int on = 1, d = 1;
	while (on < sz(P))
		on *= 2, d++;
	vector<vi> jmp(d, P);
	rep(i, 1, d) rep(j, 0, sz(P))
		jmp[i][j] = jmp[i - 1][jmp[i - 1][j]];
	return jmp;
}

void solve() {
	string s;
	cin >> s;
	string p;
	cin >> p;
	int q;
	cin >> q;
	vector<array<int, 4>> qu(q);
	for (int i = 0; i < q; i++) {
		for (int j = 0; j < 4; j++) {
			cin >> qu[i][j];
			qu[i][j]--;
		}
	}

	int n = sz(s);
	int m = sz(p);

	vi fpi = pi(p + "$" + s);
	reverse(all(s));
	reverse(all(p));
	vi rpi = pi(p + "$" + s);

	FT focc(n);
	for (int i = 0; i < n; i++) {
		if (fpi[m + 1 + i] == m)
			focc.update(i, 1);
	}

	FT rocc(n);
	for (int i = 0; i < n; i++) {
		if (rpi[m + 1 + i] == m)
			rocc.update(i, 1);
	}

	vi ftree_par(m + 1);
	for (int i = 0; i < m; i++) {
		ftree_par[i + 1] = fpi[i];
	}
	vvi ftree_jmp = treeJump(ftree_par);
	// for (ll i : ftree_par)
		// cerr << i << " ";
	// cerr << nl;

	vi rtree_par(m + 1);
	for (int i = 0; i < m; i++) {
		rtree_par[i + 1] = rpi[i];
	}
	vvi rtree_jmp = treeJump(rtree_par);
	// for (ll i : rtree_par)
		// cerr << i << " ";
	// cerr << nl;

	vi ans(q);
	vector<vector<pii>> cross_query(n);
	for (int i = 0; i < q; i++) {
		auto [s1_left, s1_right, s2_left, s2_right] = qu[i];
		int forward_left = s1_left;
		int forward_right = s1_right;
		int reverse_left = (n - 1) - s2_right;
		int reverse_right = (n - 1) - s2_left;

		if (forward_left + (m - 1) <= forward_right)
			ans[i] += focc.range(forward_left + (m - 1), forward_right);

		if (reverse_left + (m - 1) <= reverse_right)
			ans[i] += rocc.range(reverse_left + (m - 1), reverse_right);

		int s1_size = s1_right - s1_left + 1;
		int s2_size = s2_right - s2_left + 1;

		int forward_pi = fpi[m + 1 + forward_right];
		if (forward_pi == m)
			forward_pi = ftree_par[forward_pi];
		for (int d = sz(ftree_jmp) - 1; d >= 0; d--) {
			if (ftree_jmp[d][forward_pi] > s1_size)
				forward_pi = ftree_jmp[d][forward_pi];
		}
		if (forward_pi > s1_size)
			forward_pi = ftree_par[forward_pi];

		int reverse_pi = rpi[m + 1 + reverse_right];
		if (reverse_pi == m)
			reverse_pi = rtree_par[reverse_pi];
		for (int d = sz(rtree_jmp) - 1; d >= 0; d--) {
			if (rtree_jmp[d][reverse_pi] > s2_size)
				reverse_pi = rtree_jmp[d][reverse_pi];
		}
		if (reverse_pi > s2_size)
			reverse_pi = rtree_par[reverse_pi];

		// cerr << i << ": " << ans[i] << nl;
		// cerr << forward_pi << " " << reverse_pi << nl;

		cross_query[forward_pi].pb({reverse_pi, i});
	}

	vvi rtree_ch(m + 1);
	for (int i = 1; i <= m; i++) {
		rtree_ch[rtree_par[i]].pb(i);
	}

	int time = 0;
	vi rtree_sz(m + 1), rtree_disc(m + 1);
	function<void(int)> rtree_dfs = [&](int u) {
		rtree_sz[u] = 1;
		rtree_disc[u] = time++;
		for (int v : rtree_ch[u]) {
			rtree_dfs(v);
			rtree_sz[u] += rtree_sz[v];
		}
	};
	rtree_dfs(0);

	vvi ftree_ch(m + 1);
	for (int i = 1; i <= m; i++) {
		ftree_ch[ftree_par[i]].pb(i);
	}

	FT rtree_matches(m + 1);
	function<void(int)> ftree_dfs = [&](int u) {
		rtree_matches.update(rtree_disc[m - u], 1);
		rtree_matches.update(rtree_disc[m - u] + rtree_sz[m - u], -1);

		// cerr << u << ": ";
		// for (int v = 0; v <= m; v++)
			// cerr << rtree_matches.query(rtree_disc[v] + 1) << " ";
		// cerr << nl;

		for (auto [ru, i] : cross_query[u]) {
			ans[i] += rtree_matches.query(rtree_disc[ru] + 1);
			// if(rtree_matches.query(rtree_disc[ru] + 1) > 0)
			// 	cerr << rtree_matches.query(rtree_disc[ru] + 1) << "!" << nl;
			// cerr << i << " " << ru << " ? " << rtree_matches.query(rtree_disc[ru] + 1) << nl;
		}
		for (int v : ftree_ch[u]) {
			ftree_dfs(v);
		}

		rtree_matches.update(rtree_disc[m - u], -1);
		rtree_matches.update(rtree_disc[m - u] + rtree_sz[m - u], 1);
	};
	ftree_dfs(0);

	for (int i = 0; i < q; i++) {
		cout << ans[i] << nl;
	}
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	solve();
	return 0;
}