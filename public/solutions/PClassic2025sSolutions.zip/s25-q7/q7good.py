n,m = map(int,input().split())
nums = [int(x) for x in input().split()]
bad = set(int(x) for x in input().split())
count = [0]*32
for num in nums:
    for i in range(32):
        count[i] += (num&(1<<i) != 0)
curr = [[count[0],0],[n-count[0],1]]
curr.sort()  
def merge(a,b):
    ans = []
    l = 0
    r = 0
    while l < len(a) and r < len(b) and len(ans)<m+1:
        if a[l] < b[r]:
            ans.append(a[l])
            l+=1
        else:
            ans.append(b[r])
            r+=1
    if len(ans)>=m+1: return ans
    ans += a[l:]
    ans += b[r:]
    return ans   
for i in range(1,32):
    l1 = []
    l2 = []
    c=count[i]
    for a,b in curr:
        l1.append([a+c,b])
        l2.append([a+n-c,b+(1<<i)])
    new = merge(l1,l2)
    curr = new[:m+1]
for num in curr:
    if num[1] not in bad:
        print(num[1])
        break
            


