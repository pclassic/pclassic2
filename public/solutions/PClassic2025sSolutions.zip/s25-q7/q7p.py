n,m = map(int,input().split())
nums = [int(x) for x in input().split()]
bad = set(int(x) for x in input().split())
count = [0]*32
for num in nums:
    for i in range(32):
        count[i] += (num&(1<<i) != 0)
curr = [[count[0],0],[n-count[0],1]]
curr.sort()    
for i in range(1,32):
    new = []
    for num in curr:
        new.append([num[0]+count[i],num[1]])
        new.append([num[0]+n-count[i],num[1]+(1<<i)])
    curr = sorted(new)[:m+1]
for num in curr:
    if num[1] not in bad:
        print(num[1])
        break


            


