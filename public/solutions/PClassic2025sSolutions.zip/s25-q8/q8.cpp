#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<ll, ll> pii;

void solve() {
	int n, m, c, x, y, s, t;
	cin >> n >> m >> c >> y >> x >> s >> t;
	s--;
	t--;
	vector<array<int, 3>> edges(m);
	for (int i = 0; i < m; i++) {
		int u, v, ci;
		cin >> u >> v >> ci;
		u--;
		v--;
		edges[i] = {u, v, ci};
	}

	map<int, map<int, vi>> fadj;
	map<int, set<int>> exist;
	for (auto [u, v, c] : edges) {
		fadj[c][u].pb(v);
		fadj[c][v].pb(u);
		exist[c].insert(u);
		exist[c].insert(v);
	}

	map<int,map<int,int>> ccs;
	map<int,map<int,bool>> fvis;
	int cur_col;
	int cur_cc;
	function<void(int)> dfs = [&](int u) {
		if(fvis[cur_col][u]) return;
		ccs[cur_col][u] = cur_cc;
		fvis[cur_col][u] = true;
		for(int v : fadj[cur_col][u]) {
			dfs(v);
		}
	};
	for(auto [c, cset] : exist) {
		cur_col = c;
		cur_cc = 0;
		for(int u : cset) {
			dfs(u);
			cur_cc++;
		}
	}

	map<int, map<int, vector<pii>>> adj;
	map<int, set<int>> colors;
	for (auto [u, v, c] : edges) {
		int hub = n+ccs[c][u];
		adj[c][u].pb({hub, x});
		adj[c][hub].pb({u, 0});
		adj[c][v].pb({hub, x});
		adj[c][hub].pb({v, 0});
		colors[u].insert(c);
		colors[v].insert(c);
	}

	map<pii, bool> vis;
	map<pii, ll> dist;
	priority_queue<array<ll, 3>> pq;
	for (int c : colors[s]) {
		dist[{c, s}] = 0;
		pq.push({-0, c, s});
	}
	while (pq.size()) {
		auto [nd, c, u] = pq.top();
		pq.pop();
		ll d = -nd;
		if (vis[{c, u}])
			continue;
		vis[{c, u}] = true;
		for (auto [v, w] : adj[c][u]) {
			if (vis[{c, v}])
				continue;
			if (dist.count({c, v}) && dist.at({c, v}) <= dist.at({c, u}) + w)
				continue;
			ll vd = dist[{c, u}] + w;
			dist[{c, v}] = vd;
			pq.push({-vd, c, v});
			cerr << c << " edge " << u << "->" << v << ": " << vd << nl;
		}
		if(u != n) for (int col : colors[u]) {
			if (vis[{col, u}])
				continue;
			if (dist.count({col, u}) && dist.at({col, u}) <= dist.at({c, u}) + y)
				continue;
			ll ucd = dist.at({c, u}) + y;
			dist[{col, u}] = ucd;
			pq.push({-ucd, col, u});
			cerr << u << " color " << c << "->" << col << ": " << ucd << nl;
		}
	}

	for(auto [pr, sf] : vis) {
		auto [c, v] = pr;
		cerr << c << " " << v << "!" << nl;
	}

	ll ans = LONG_LONG_MAX;
	for (int col : colors[t]) {
		if (vis.count({col, t}))
			ans = min(ans, dist[{col, t}]);
	}

	if(ans == LONG_LONG_MAX) ans = -1;

	cout << ans << nl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	solve();
	return 0;
}