
import sys
import heapq
from collections import defaultdict, deque
input = sys.stdin.readline
n, m, C, s_cost, t_cost, start, target = map(int, input().split())
start -= 1
target -= 1
incident_colours = [set() for _ in range(n)]
adj_by_colour = defaultdict(lambda: defaultdict(list))
for _ in range(m):
    u, v, col = map(int, input().split())
    u -= 1
    v -= 1
    col -= 1
    incident_colours[u].add(col)
    incident_colours[v].add(col)
    adj_by_colour[col][u].append(v)
    adj_by_colour[col][v].append(u)

edges = [[] for _ in range(n)] 
def new_node():
    edges.append([])
    return len(edges) - 1
VC_id = {}
def get_VC(v, col):
    key = (v, col)
    if key in VC_id:
        return VC_id[key]
    vc = new_node()
    VC_id[key] = vc
    hub = v
    edges[vc].append((hub, 0))
    edges[hub].append((vc, s_cost))
    return vc
for col, adj in adj_by_colour.items():
    visited = set()
    for v in adj:
        if v in visited:
            continue
        comp_vertices = []
        dq = deque([v])
        visited.add(v)
        while dq:
            x = dq.pop()
            comp_vertices.append(x)
            for y in adj[x]:
                if y not in visited:
                    visited.add(y)
                    dq.append(y)
        cc = new_node()
        for u in comp_vertices:
            vc = get_VC(u, col)
            edges[vc].append((cc, 0))
            edges[cc].append((vc, t_cost))
N = len(edges)
dist = [float("inf")] * N
pq = []
def push(node, d):
    if d < dist[node]:
        dist[node] = d
        heapq.heappush(pq, (d, node))
hub_start = start
hub_target = target
if incident_colours[start]:
    for col in incident_colours[start]:
        push(get_VC(start, col), 0)
else:
    push(hub_start, 0)
push(hub_start, 0)
while pq:
    d_u, u = heapq.heappop(pq)
    if d_u != dist[u]:
        continue
    if u == hub_target:
        break
    for v, w in edges[u]:
        push(v, d_u + w)
ans = dist[hub_target]
print(ans if ans < float("inf") else -1)