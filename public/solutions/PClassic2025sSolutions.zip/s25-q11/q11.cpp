#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for (int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<int, int> pii;

constexpr ll MOD = 1'000'000'007;

ll mexp(ll a, ll b) {
	if (b == 0)
		return 1;
	if (b % 2 == 1)
		return (a * mexp(a, b - 1)) % MOD;
	ll x = mexp(a, b / 2);
	return (x * x) % MOD;
}

ll minv(ll x) {
	return mexp(x, MOD - 2);
}

constexpr int XMAX = 1'000'005;

vi fact(4 * XMAX);

ll binom(ll n, ll k) {
	cerr << n << " C " << k << nl;
	ll ans = (fact[n] * ((minv(fact[n - k]) * minv(fact[k])) % MOD)) % MOD;
	return ans;
}

void solve() {
	int n, x;
	cin >> n >> x;
	vi r(n);
	for (int i = 0; i < n; i++) {
		cin >> r[i];
	}

	if (n == 1) {
		cout << 1 << nl;
		return;
	}

	ll y = 0;
	for (int ri : r)
		y += 2 * ri;

	sort(all(r));
	if (y > x + r[n-1] + r[n-2]) {
		cout << 0 << nl;
		return;
	}

	fact[0] = 1;
	for (int i = 1; i < sz(fact); i++) {
		fact[i] = (fact[i - 1] * i) % MOD;
	}

	ll ans = 0;

	map<int, ll> rocc;
	for (int ri : r)
		rocc[ri]++;

	map<int, ll> sum_occ;
	for (auto [ri, ci] : rocc) {
		for (auto [rj, cj] : rocc) {
			if (ri == rj)
				sum_occ[ri + rj] += ci * (ci - 1);
			else
				sum_occ[ri + rj] += ci * cj;
		}
	}
	for (auto [sum, occ] : sum_occ) {
		if(x - y + sum < 0) continue;
		ans += occ * binom(x - y + sum + (n - 2) + 1, (n - 2) + 1);
		ans %= MOD;
	}

	ans *= fact[n - 2];
	ans %= MOD;

	cout << ans << nl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	solve();
	return 0;
}