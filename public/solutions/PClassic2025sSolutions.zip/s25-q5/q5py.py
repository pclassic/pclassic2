import math

def is_square(x):
    r = int(math.isqrt(x))
    return r*r == x

def remove_zeros(x):
    return int(str(x).replace('0', ''))

def count_squares(n):
    cnt = 0
    x = 1
    while (xsq := x*x) <= n:
        if is_square(remove_zeros(xsq)): cnt += 1
        x += 1
    return cnt

if __name__ == "__main__":
    n = int(input())
    print(count_squares(n))
