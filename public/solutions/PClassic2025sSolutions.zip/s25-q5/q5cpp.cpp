// #include <bits/stdc++.h>
#include <iostream>
#include <cmath>

using namespace std;
using ll = long long;

bool is_square(ll x) {
  ll r = sqrtl(x);
  return r*r == x;
}

ll remove_zeros(ll x) {
  ll res = 0, place = 1;
  while (x > 0) {
    ll d = x % 10;
    if (d != 0) {
      res += d * place;
      place *= 10;
    }
    x /= 10;
  }
  return res;
}

ll count_squares(ll n) {
  ll cnt = 0;
  for (ll x = 1; x <= sqrtl(n); x++) {
    ll xsq = x*x;
    ll xsq_nozero = remove_zeros(xsq);
    if (is_square(xsq_nozero)) {
      cnt++;
    }
  }
  return cnt;
}

int main() {
  ll n;
  cin >> n;

  cout << count_squares(n) << endl;

  return 0;
}
