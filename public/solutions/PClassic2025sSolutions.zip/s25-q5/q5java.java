import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q5java {
    public static boolean verifyPerfectSquares(long x) {
        // remove zeroes
        String s = Long.toString(x);
        s = s.replace("0", "");
        
        long result = 0;
        if (!s.isEmpty()) result = Long.parseLong(s);
        
        long r = (long) Math.sqrt(result);
        return r * r == result;
    }

    public static int numberOfPerfectSquares(long n) {
        int count = 0;

        long x = 1;
        while (true) {
            long square = x * x;

            if (square > n) break;

            if (verifyPerfectSquares(square)) count += 1;

            x++;
        }

        return count;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        long n = Long.parseLong(br.readLine());

        System.out.println(numberOfPerfectSquares(n));
    }
}