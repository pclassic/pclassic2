from math import isqrt
n = int(input())
seen = set()
ans = 0
for i in range(1,isqrt(n)+1):
    curr = i*i
    s = int("".join(x for x in str(curr) if x!="0"))
    if s == curr or s in seen: ans+=1
    seen.add(curr)
print(ans)