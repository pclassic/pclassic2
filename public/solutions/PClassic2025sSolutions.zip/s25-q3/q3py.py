from math import gcd
for _ in range(int(input())):
    w,x,y,z = map(int,input().split())
    g1 = gcd(w,x)
    g2 = gcd(y,z)
    w//=g1
    x//=g1
    y//=g2
    z//=g2
    for b in range(1,x*z+1):
        a = w*b//x + 1
        if a*z < b*y:
            print(a,b)
            break

