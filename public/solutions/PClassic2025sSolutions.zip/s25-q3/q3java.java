import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q3java {
    public static void printMinimalDenominatorFraction(int w, int x, int y, int z) {
        int b = 1;

        while (true) {
            int minA = 0;
            int maxA = (y * b) / z;
    
            minA = (w * b) % x == 0 ? (w * b) / x + 1 : (w * b + x) / x;
        
            if (minA <= maxA) {
                System.out.println(maxA + " " + b);
                break;
            }
            b++;
        }
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());

        for (int i = 0; i < t; i++) {
            String[] currLine = br.readLine().split(" ");
            int w = Integer.parseInt(currLine[0]);
            int x = Integer.parseInt(currLine[1]);
            int y = Integer.parseInt(currLine[2]);
            int z = Integer.parseInt(currLine[3]);

            printMinimalDenominatorFraction(w, x, y, z);
        }

    }
}