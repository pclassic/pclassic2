#include <iostream>
using namespace std;

void q3solver(int w, int x, int y, int z) {
    int b = 1;

    while (true) {
        int a_min;
        if ((w * b) % x == 0) {
            a_min = (w * b) / x + 1;
        } else {
            a_min = (w * b + x) / x;
        }

        int a_max = (y * b) / z;

        if (a_min <= a_max) {
            int a = a_min;
            cout << a << " " << b << endl;
            return;
        }

        b++;
    }
}

int main() {
    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        int w, x, y, z;
        cin >> w >> x >> y >> z;

        q3solver(w, x, y, z);
    }

    return 0;
}