import java.io.BufferedReader;
import java.util.*;
import java.lang.Math;
import java.io.FileReader;
import java.io.IOException;

public class Proximity {

	public static void main(String[] args) throws IOException {
		//turn input from file into arrays
		BufferedReader br = new BufferedReader(new FileReader("ProximityIN.txt"));
		
		while (br.ready()) {
			String[] data1 = br.readLine().split(" ");
			int[] l = new int[data1.length];
			for (int i = 0; i < data1.length; i++)
			{
				l[i] = Integer.parseInt(data1[i]);
			}
			String[] data2 = br.readLine().split(" ");
			int[] m = new int[data2.length];
			for (int i = 0; i < data2.length; i++)
			{
				m[i] = Integer.parseInt(data2[i]);
			}
			
			int[] output = twoClosest(l, m); //calls the method on the arrays
			
			for (int i = 0; i < output.length; i++)
				System.out.print(output[i] + " ");
			
			System.out.println("");
		}
	}
	
	public static int[] twoClosest (int[] a1, int[] a2)
	{
		int[] soln = new int[a2.length * 2];
		
		if (a1.length == 1)
		{
			for (int i = 0; i < soln.length; i++)
				soln[i] = a1[0];
			
			return soln;
		}
		
		for (int i = 0; i < a2.length; i++)
		{
			int minDist = Math.abs(a2[i] - a1[0]);
			int min = a1[0];
			int minIndex = 0;
			for (int j = 0; j < a1.length; j++) //identify closest number
			{
				if (Math.abs(a2[i] - a1[j]) < minDist)
				{
					minDist = Math.abs(a2[i] - a1[j]);
					min = a1[j];
					minIndex = j;
				}
			}
			
			soln[2*i] = min;
			
			int secondLeastDist, secondLeast;
			if (minIndex != 0) 
			{
				secondLeastDist = Math.abs(a2[i] - a1[0]);
				secondLeast = a1[0];
			}
			else
			{
				secondLeastDist = Math.abs(a2[i] - a1[1]);
				secondLeast = a1[1];
			}
			
			for (int j = 0; j < a1.length; j++) //identify second closest
			{
				if ((Math.abs(a2[i] - a1[j]) < secondLeastDist) && (minIndex!=j))
				{
						secondLeastDist = Math.abs(a2[i] - a1[j]);
						secondLeast = a1[j];
					
				}
			}
			
			soln[2*i + 1] = secondLeast;
		}
		return soln;
	}
}