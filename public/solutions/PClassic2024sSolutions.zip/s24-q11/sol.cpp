#include <algorithm>
#include <array>
#include <bitset>
#include <cassert>
#include <chrono>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iostream>
#include <iomanip>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <random>
#include <set>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;

#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define mp(a, b) make_pair(a, b)
#define pb push_back
#define f first
#define s second
#define nl '\n'
#define sz(v) (long long) v.size()

#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}

typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;

const ll inf = 1e16;

const int MOD = 1e9 + 7;
typedef decay<decltype(MOD)>::type T;
struct mi {
  T val;
  explicit operator T() const { return val; }
  mi() { val = 0; }
  mi(const long long& v) {
    val = (-MOD <= v && v < MOD) ? v : v % MOD;
    if (val < 0) val += MOD; }
  friend ostream& operator<<(ostream& os, const mi& a) { return os << a.val; }
  friend bool operator==(const mi& a, const mi& b) { return a.val == b.val; }
  friend bool operator!=(const mi& a, const mi& b) { return !(a == b); }
  friend bool operator<(const mi& a, const mi& b) { return a.val < b.val; }
  mi operator-() const { return mi(-val); }
  mi& operator+=(const mi& m) {
    if ((val += m.val) >= MOD) val -= MOD;
    return *this; }
  mi& operator-=(const mi& m) {
    if ((val -= m.val) < 0) val += MOD;
    return *this; }
  mi& operator*=(const mi& m) { val = (long long) val * m.val % MOD;
    return *this; }
  friend mi pow(mi a, long long p) {
    mi ans = 1; assert(p >= 0);
    for (; p; p /= 2, a *= a) if (p & 1) ans *= a;
    return ans; }
  friend mi inv(const mi& a) { assert(a != 0); return pow(a, MOD - 2); }
  mi& operator/=(const mi& m) { return (*this) *= inv(m); }
  friend mi operator+(mi a, const mi& b) { return a += b; }
  friend mi operator-(mi a, const mi& b) { return a -= b; }
  friend mi operator*(mi a, const mi& b) { return a *= b; }
  friend mi operator/(mi a, const mi& b) { return a /= b; }
};

void construct_graph(int k, ll n, ll m, vector<vector<int>>& graph, const vector<vector<ll>>& rects) {
  // sweep y
  map<ll, vector<int>> mpy;
  // sweep x
  map<ll, vector<int>> mpx;

  for (int i = 0; i < sz(rects); i++) {
    auto rect = rects[i];
    ll lx = rect[0];
    ll ly = rect[1];
    ll ux = rect[2] + 1;
    ll uy = rect[3] + 1;

    if (ly == 0LL) {
      graph[k+1].pb(i+1);
      graph[i+1].pb(k+1);
    }
    if (lx == 0LL) {
      graph[0].pb(i+1);
      graph[i+1].pb(0);
    }
    if (ux == n) {
      graph[k+1].pb(i+1);
      graph[i+1].pb(k+1);
    }
    if (uy == m) {
      graph[0].pb(i+1);
      graph[i+1].pb(0);
    }

    mpx[lx].pb(i);
    mpx[ux].pb(i);
    mpy[ly].pb(i);
    mpy[uy].pb(i);
  }

  for (const auto& [yval, v] : mpy) {
    set<int> cur;
    vector<pair<ll, int>> vx;
    for (int idx: v) {
      auto rect = rects[idx];
      vx.pb({rect[0], -(idx + 1)});
      vx.pb({rect[2] + 1, idx + 1});
    }

    sort(vx.begin(), vx.end());

    for (auto p: vx) {
      int idx = p.s;
      if (idx < 0) {
        for (int idx2: cur) {
          //cout << "yeah!" << endl;
          graph[-idx].pb(idx2);
          graph[idx2].pb(-idx);
        }
        cur.insert(-idx);
      } else {
        cur.erase(idx);
      }
    }
  }

  for (const auto& [xval, v]: mpx) {
    set<int> cur;
    vector<pair<ll, int>> vy;
    for (int idx: v) {
      auto rect = rects[idx];
      vy.pb({rect[1], -(idx + 1)});
      vy.pb({rect[3] + 1, idx + 1});
    }

    sort(vy.begin(), vy.end());

    for (auto p: vy) {
      int idx = p.s;
      if (idx < 0) {
        for (int idx2: cur) {
          //cout << "yeah2!" << endl;
          graph[-idx].pb(idx2);
          graph[idx2].pb(-idx);
        }
        cur.insert(-idx);
      } else {
        cur.erase(idx);
      }
    }
  }
}

void solve() {
  ll n, m; cin >> n >> m;
  int k; cin >> k;
  vector<vector<ll>> rects(k, vector<ll>(4));

  for (int i = 0; i < k; i++) {
    cin >> rects[i][0] >> rects[i][1] >> rects[i][2] >> rects[i][3];
  }
 
  // 0 is the left/top and k + 1 is the bottom/right
  vector<vector<int>> graph(k + 2);

  construct_graph(k, n, m, graph, rects);

  /*for (int i = 0; i <= k + 1; i++) {
    cout << i << ":";
    for (int x: graph[i]) {
      cout << " " << x;
    }
    cout << endl;
  }*/

  // bfs to find the shortest path
  vector<int> par(k + 2);
  vector<bool> vis(k + 2);

  queue<int> q;
  q.push(0);
  vis[0] = 1;
  par[0] = -1;

  while (!q.empty()) {
    int cur = q.front();
    q.pop();
    for (int v: graph[cur]) {
      if (!vis[v]) {
        vis[v] = 1;
        par[v] = cur;
        q.push(v);
      }
    }
  }

  if (vis[k + 1]) {
    vector<int> ret;
    int cur = k + 1;
    while (cur > 0) {
      ret.pb(cur);
      cur = par[cur];
    }

    cout << sz(ret) - 1;
    for (int i = sz(ret) - 1; i > 0; i--) {
      cout << " " << ret[i];
    }
    cout << nl;
  } else {
    cout << -1 << nl;
  }
}

int main() {
  ios_base::sync_with_stdio(false); cin.tie(NULL);

  int t = 1;
  while (t--) {
    solve();
  }
}

