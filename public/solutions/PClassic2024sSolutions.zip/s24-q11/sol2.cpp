#include <bits/stdc++.h>
using namespace std;

#ifdef LOCAL
#define DEBUG(...) debug(#__VA_ARGS__, __VA_ARGS__)
#else
#define DEBUG(...) 6
#endif

template<typename T, typename S> ostream& operator << (ostream &os, const pair<T, S> &p) {return os << "(" << p.first << ", " << p.second << ")";}
template<typename C, typename T = decay<decltype(*begin(declval<C>()))>, typename enable_if<!is_same<C, string>::value>::type* = nullptr>
ostream& operator << (ostream &os, const C &c) {bool f = true; os << "["; for (const auto &x : c) {if (!f) os << ", "; f = false; os << x;} return os << "]";}
template<typename T> void debug(string s, T x) {cerr << "\033[1;35m" << s << "\033[0;32m = \033[33m" << x << "\033[0m\n";}
template<typename T, typename... Args> void debug(string s, T x, Args... args) {for (int i=0, b=0; i<(int)s.size(); i++) if (s[i] == '(' || s[i] == '{') b++; else
if (s[i] == ')' || s[i] == '}') b--; else if (s[i] == ',' && b == 0) {cerr << "\033[1;35m" << s.substr(0, i) << "\033[0;32m = \033[33m" << x << "\033[31m | "; debug(s.substr(s.find_first_not_of(' ', i + 1)), args...); break;}}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m, k;
    cin >> n >> m >> k;
    vector<vector<int>> adj(k + 2);

    auto addEdge = [&] (int u, int v) -> void {
        adj[u].push_back(v);
        adj[v].push_back(u);
    };

    vector<array<int, 4>> rect;
    for (int i=0; i<k; i++) {
        int ax, ay, bx, by;
        cin >> ax >> ay >> bx >> by;
        if (ax == 0 || by == m - 1)
            addEdge(i, k);
        if (bx == n - 1 || ay == 0)
            addEdge(i, k + 1);
        rect.push_back({ax, ay, bx, by});
    }

    // should be able to construct graph explicitly as it's a planar graph
    for (int rep=0; rep<2; rep++) {
        map<int, map<int, vector<pair<int, int>>>> mp;
        for (int i=0; i<k; i++) {
            auto [ax, ay, bx, by] = rect[i];
            mp[bx][ay].emplace_back(by, i);
        }
        for (auto &[_, mp2] : mp)
            for (auto &[_, v] : mp2)
                sort(v.rbegin(), v.rend());
        for (int i=0; i<k; i++) {
            auto [ax, ay, bx, by] = rect[i];
            if (mp.count(ax - 1)) {
                const auto &mp2 = mp[ax-1];
                auto it = mp2.begin();
                while (it != mp2.end() && it->first <= by + 1) {
                    int j = 0;
                    while (j < (int) it->second.size() && it->second[j].first >= ay - 1) {
                        addEdge(i, it->second[j].second);
                        j++;
                    }
                    it++;
                }
            }
        }

        for (auto &[ax, ay, bx, by] : rect) {
            swap(ax, ay);
            swap(bx, by);
        }
    }

    vector<int> par(k + 2, -1);
    queue<int> que;
    par[k] = -2;
    que.push(k);
    while (!que.empty()) {
        int u = que.front();
        que.pop();
        for (int v : adj[u])
            if (par[v] == -1) {
                par[v] = u;
                que.push(v);
            }
    }

    if (par[k+1] == -1) {
        cout << "-1\n";
    } else {
        vector<int> ret;
        for (int u=par[k+1]; u!=k; u=par[u])
            ret.push_back(u);
        reverse(ret.begin(), ret.end());

        cout << ret.size();
        for (int x : ret)
            cout << " " << x + 1;
        cout << "\n";
    }

    return 0;
}
