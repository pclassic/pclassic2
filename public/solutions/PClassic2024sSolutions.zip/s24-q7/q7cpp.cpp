#include <iostream>
#include <vector>
#include <cmath>
using namespace std;


void solve() {
    int n;
    cin >> n;
    vector<int> x(n);
    vector<int> v(n);
    for (int i = 0; i < n; i++) {
        cin >> x[i];
    }
    for (int i = 0; i < n; i++) {
        cin >> v[i];
    }

    int ngroups = 0;
    // set variable min to largest integer value
    int suffix_min = INT_MAX;
    for (int i = n-1; i >=0; i--) {
        if (v[i] <= suffix_min) {
            ngroups++;
            suffix_min = v[i];
        }
    }
    cout << ngroups << endl;
    

}

int main() {
    ios::sync_with_stdio(false);
	cin.tie(NULL);
    int t;
    cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}