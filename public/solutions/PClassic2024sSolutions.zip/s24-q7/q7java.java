import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q7java {

    public static long highway(int[] x, int[] v) {
        int ngroups = 0;
        int suffix_min = Integer.MAX_VALUE;
        for (int i = v.length - 1; i >= 0; i--) {
            if (v[i] <= suffix_min) {
                ngroups++;
                suffix_min = v[i];
            }
        }
        return ngroups;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());
        for (int q=0; q < t; q++) {
            int n = Integer.parseInt(br.readLine());
            String[] xStrings = br.readLine().split(" ");
            int[] x = new int[n];
            for (int i = 0; i < n; i++) {
                x[i] = Integer.parseInt(xStrings[i]);
            }
            String[] vStrings = br.readLine().split(" ");
            int[] v = new int[n];
            for (int i = 0; i < n; i++) {
                v[i] = Integer.parseInt(vStrings[i]);
            }
            System.out.println(Long.toString(highway(x, v)));
        }
    }

}