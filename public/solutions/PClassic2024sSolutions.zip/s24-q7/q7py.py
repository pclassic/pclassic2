from typing import List 

def highway(_: List[int], spd: List[int]) -> int:
    ngroups = 0
    suffix_min = float('inf')
    for x in spd[::-1]:
        if x <= suffix_min:
            ngroups += 1
            suffix_min = x
    return ngroups

if __name__ == "__main__":
    ntests = int(input())
    for _ in range(ntests):
        ncars = int(input())
        pos = [int(x) for x in input().split(' ')]
        spd = [int(v) for v in input().split(' ')]
        print(highway(pos, spd))