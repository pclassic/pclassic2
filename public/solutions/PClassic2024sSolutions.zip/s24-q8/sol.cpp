#include <algorithm>
#include <array>
#include <bitset>
#include <cassert>
#include <chrono>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iostream>
#include <iomanip>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <random>
#include <set>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;

#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define mp(a, b) make_pair(a, b)
#define pb push_back
#define f first
#define s second
#define nl '\n'
#define sz(v) (long long) v.size()

#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}

typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;

const ll inf = 1e16;

const int MOD = 1e9 + 7;
typedef decay<decltype(MOD)>::type T;
struct mi {
  T val;
  explicit operator T() const { return val; }
  mi() { val = 0; }
  mi(const long long& v) {
    val = (-MOD <= v && v < MOD) ? v : v % MOD;
    if (val < 0) val += MOD; }
  friend ostream& operator<<(ostream& os, const mi& a) { return os << a.val; }
  friend bool operator==(const mi& a, const mi& b) { return a.val == b.val; }
  friend bool operator!=(const mi& a, const mi& b) { return !(a == b); }
  friend bool operator<(const mi& a, const mi& b) { return a.val < b.val; }
  mi operator-() const { return mi(-val); }
  mi& operator+=(const mi& m) {
    if ((val += m.val) >= MOD) val -= MOD;
    return *this; }
  mi& operator-=(const mi& m) {
    if ((val -= m.val) < 0) val += MOD;
    return *this; }
  mi& operator*=(const mi& m) { val = (long long) val * m.val % MOD;
    return *this; }
  friend mi pow(mi a, long long p) {
    mi ans = 1; assert(p >= 0);
    for (; p; p /= 2, a *= a) if (p & 1) ans *= a;
    return ans; }
  friend mi inv(const mi& a) { assert(a != 0); return pow(a, MOD - 2); }
  mi& operator/=(const mi& m) { return (*this) *= inv(m); }
  friend mi operator+(mi a, const mi& b) { return a += b; }
  friend mi operator-(mi a, const mi& b) { return a -= b; }
  friend mi operator*(mi a, const mi& b) { return a *= b; }
  friend mi operator/(mi a, const mi& b) { return a /= b; }
};

void solve() {
  int n; cin >> n;
  vector<vector<int>> grid(n, vector<int>(n));

  vector<int> rc;
  vector<int> c;

  int remrows = n, remcols = n;
  int nz = 0;

  vector<bool> remr(n), remc(n);
  for (int i = 0; i < n; i++) {
    remr[i] = 1;
    remc[i] = 1;
  }

  vector<vector<int>> numr(n, vector<int>(2)), numc(n, vector<int>(2));

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      cin >> grid[i][j];
      if (grid[i][j] == 0) {
        nz++;
      } else {
        numr[i][grid[i][j] - 1]++;
        numc[j][grid[i][j] - 1]++;
      }
    }
  }

  int cont = 1;
  while (cont) {
    if (remrows == 0 || remcols == 0) break;
    cont = 0;
    
    for (int i = 0; i < n; i++) {
      if (!remr[i]) continue;
      if (remcols == numr[i][1]) {
        // no ones
        assert(numr[i][0] == 0);
        for (int j = 0; j < n; j++) {
          if (remc[j]) {
            numc[j][1]--;
          }
        }

        remr[i] = 0;
        remrows--;
        cont = 1;
        rc.pb(i+1);
        c.pb(2);
        break;
      } else if (remcols == numr[i][0]) {
        // no twos
        assert(numr[i][1] == 0); 
        for (int j = 0; j < n; j++) {
          if (remc[j]) {
            numc[j][0]--;
          }
        }

        remr[i] = 0;
        remrows--;
        cont = 1;
        rc.pb(i+1);
        c.pb(1);
        break;
      }
    }


    if (cont) continue;
    
    for (int i = 0; i < n; i++) {
      if (!remc[i]) continue;
      if (remrows == numc[i][1]) {
        // no ones
        assert(numc[i][0] == 0);
        for (int j = 0; j < n; j++) {
          if (remr[j]) {
            numr[j][1]--;
          }
        }

        remc[i] = 0;
        remcols--;
        cont = 1;
        rc.pb(-(i+1));
        c.pb(2);
        break;
      } else if (remrows == numc[i][0]) {
        // no twos 
        assert(numc[i][1] == 0);
        for (int j = 0; j < n; j++) {
          if (remr[j]) {
            numr[j][0]--;
          }
        }

        remc[i] = 0;
        remcols--;
        cont = 1;
        rc.pb(-(i+1));
        c.pb(1);
        break;
      }
    }
  }

  if (remrows * remcols != nz) {
    cout << -1 << nl;
  } else {
    cout << sz(rc) << nl;
    for (int i = sz(rc) - 1; i >= 0; i--) {
      //cout << (rc[i] > 0 ? "row" : "col" )<< " " << abs(rc[i]) << " " << c[i] << nl;
      cout << (rc[i] > 0 ? 0 : 1 )<< " " << abs(rc[i]) << " " << c[i] << nl;
    }
  }
}

int main() {
  ios_base::sync_with_stdio(false); cin.tie(NULL);

  int t; cin >> t;
  while (t--) {
    solve();
  }
}

