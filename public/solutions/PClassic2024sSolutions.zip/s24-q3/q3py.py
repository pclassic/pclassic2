import math

def php(total, wins):
   return math.ceil((total-wins)/(wins+1))


if __name__ == "__main__":
    n, t = list(map(int, input().split()))
    print(php(n,t))