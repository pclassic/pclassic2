import java.util.Scanner;
import java.lang.Math;

public class q3java {
	public static void main(String[] args) {

	    Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int v = in.nextInt();
		System.out.println(php(n, v));
		in.close();
	}
	
	public static int php(int total, int wins) {
		return (int) Math.ceil( (double) (total - wins) / (wins + 1));
	}
}
