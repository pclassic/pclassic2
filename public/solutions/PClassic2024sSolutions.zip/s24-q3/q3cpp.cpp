#include <iostream>
#include <vector>
#include <cmath>
using namespace std;


void solve() {
    int total, wins;
    cin >> total >> wins;
    cout << (total)/(wins+1) << endl;

}

int main() {
    ios::sync_with_stdio(false);
	cin.tie(NULL);
    solve();
    return 0;
}