#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<int,int> pii;

constexpr int MOD = 1e9+7;
constexpr int N = 200'005;
vi lp(N+1);
vi inv(N+1);
vector<map<int,int>> pf(N+1);

ll mexp(ll a, ll b) {
	if(b == 0) return 1;
	if(b % 2 == 1) return (a*mexp(a,b-1))%MOD;
	ll x = mexp(a, b/2);
	return (x*x)%MOD;
}
ll minv(ll x) {
	return mexp(x, MOD-2);
}

constexpr int K = 4; // >= max removes + 1
struct LCMCont {
	vector<multiset<int>> ord_pf;
	ll ord = 1;
	LCMCont(vi cyc, int n) : ord_pf(n+1) {
		for(int i = 1; i <= n; i++) {
			for(int j = 0; j < K; j++) {
				ord_pf[i].insert(0);
			}
		}
		for(int i = 1; i <= n; i++) {
			for(int j = 0; j < cyc[i]; j++) {
				for(auto [p, e] : pf[i]) {
					ord_pf[p].insert(e);
					ord_pf[p].erase(ord_pf[p].begin());
				}
			}
		}
		for(int i = 1; i <= n; i++) {
			int e = *ord_pf[i].rbegin();
			for(int j = 0; j < e; j++) {
				ord *= i;
				ord %= MOD;
			}
		}
	}
	void remove(int x) {
		// cout << "remove " << x << "!" << endl;
		for(auto [p, e] : pf[x]) {
			auto it = ord_pf[p].find(e);
			if(it == ord_pf[p].end()) continue;
			ord_pf[p].erase(it);
			int e2 = *ord_pf[p].rbegin();
			for(int j = e-1; j >= e2; j--) {
				ord *= inv[p];
				ord %= MOD;
			}
		}
	}
	void add(int x) {
		// cout << "add " << x << "!" << endl;
		for(auto [p, e] : pf[x]) {
			int e2 = *ord_pf[p].rbegin();
			for(int j = e2; j < e; j++) {
				ord *= p;
				ord %= MOD;
			}
			ord_pf[p].insert(e);
		}
	}
};

void solve() {
	int n;
	cin >> n;
	vi p(n);
	for(int i = 0; i < n; i++) {
		cin >> p[i];
		p[i]--;
	}


	vb vis(n);
	vi cyc(n+1);
	vi ord(n);
	for(int i = 0; i < n; i++) {
		if(vis[i]) continue;
		int s = 0;
		int j = i;
		do {
			vis[j] = true;
			s++;
			j = p[j];
		} while(!vis[j]);
		cyc[s]++;
		ord[i] = s;
	}

	// for(int x : cyc) cout << x << " ";
	// cout << endl;

	LCMCont l(cyc, n);

	// cout << l.ord << "!" << endl;

	array<ll,4> ans = {0, 0, 0, 0};

	// cutting swaps (i and j in same cycle)
	for(int i = 1; i <= n; i++) {
		if(cyc[i] == 0) continue;
		l.remove(i);
		for(int j = 1; j < i; j++) {
			l.add(j);
			l.add(i-j);
			array<ll,4> cur = {l.ord, i, j, 0};
			// for(ll x : cur) cout << x << " ";
			// cout << endl;
			if(cur > ans) ans = cur;
			l.remove(j);
			l.remove(i-j);
		}
		l.add(i);
	}

	set<int> cyc_siz;
	for(int i = 1; i <= n; i++) {
		if(cyc[i] != 0) cyc_siz.insert(i);
	}
	// merging swaps
	for(int x : cyc_siz) {
		l.remove(x);
		for(int y : cyc_siz) {
			if(x == y && cyc[y] == 1) continue;
			l.remove(y);
			l.add(x+y);
			array<ll,4> cur = {l.ord, x, y, 1};
			// for(ll x : cur) cout << x << " ";
			// cout << endl;
			if(cur > ans) ans = cur;
			l.remove(x+y);
			l.add(y);
		}
		l.add(x);
	}

	ll order = ans[0];
	if(ans[3] == 0) {
		// cutting
		int x = ans[1], y = ans[2];
		int ans_i = -1;
		for(int i = 0; i < n; i++) {
			if(ord[i] == x) ans_i = i;
		}
		int ans_j = ans_i;
		for(int i = 0; i < y; i++) {
			ans_j = p[ans_j];
		}
		cout << order << " " << ans_i+1 << " " << ans_j+1 << nl;
	} else {
		// merging
		int x = ans[1], y = ans[2];
		int ans_i = -1;
		for(int i = 0; i < n; i++) {
			if(ord[i] == x) ans_i = i;
		}
		int ans_j = -1;
		for(int i = 0; i < n; i++) {
			if(ord[i] == y && i != ans_i) ans_j = i;
		}
		cout << order << " " << ans_i+1 << " " << ans_j+1 << nl;
	}
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);

	for(int i = 2; i <= N; i++) {
		if(lp[i]) continue;
		for(int j = i; j <= N; j += i) {
			if(!lp[j]) lp[j] = i;
		}
	}

	for(int i = 1; i <= N; i++) {
		inv[i] = minv(i);
	}

	for(int i = 2; i <= N; i++) {
		pf[i] = pf[i/lp[i]];
		pf[i][lp[i]]++;
	}

	int t;
	cin >> t;
	while(t--) {
		solve();
	}
	return 0;
}