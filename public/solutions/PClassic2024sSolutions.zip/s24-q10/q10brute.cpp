#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<int,int> pii;

constexpr int MOD = 1e9+7;
constexpr int N = 200'005;
vector<int> lp(N+1);
vector<int> pr;

vi cyc(vi p) {
	int n = sz(p);
	vb vis(n);
	vi ret;
	for(int i = 0; i < n; i++) {
		if(vis[i]) continue;
		int s = 0;
		int j = i;
		do {
			vis[j] = true;
			s++;
			j = p[j];
		} while(j != i);
		ret.pb(s);
	}
	return ret;
}

vector<pii> factors(int x) {
	map<int,int> pf;
	while(x > 1) {
		int p = lp[x];
		pf[p]++;
		x /= p;
	}
	return vector<pii>(all(pf));
}

int modlcm(vi p) {
	vi c = cyc(p);

	map<int,int> pf;
	for(int x : c) {
		vector<pii> pfc = factors(x);
		for(auto [p, e] : pfc) {
			pf[p] = max(pf[p], e);
		}
	}

	ll ans = 1;
	for(auto [p, e] : pf) {
		for(int i = 0; i < e; i++) {
			ans = ans*p;
			ans %= MOD;
		}
	}
	return ans;
}

void solve() {
	int n;
	cin >> n;
	vi p(n);
	for(int i = 0; i < n; i++) {
		cin >> p[i];
		p[i]--;
	}

	array<int,3> ans = {0, 0, 0};
	for(int i = 0; i < n; i++) {
		for(int j = 0; j < n; j++) {
			if(i == j) continue;
			vi q(all(p));
			swap(q[i], q[j]);
			int r = modlcm(q);
			ans = max(ans, array<int,3>{r,i,j});
		}
	}

	cout << ans[0] << " " << ans[1]+1 << " " << ans[2]+1 << nl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);

	for (int i=2; i <= N; ++i) {
		if (lp[i] == 0) {
			lp[i] = i;
			pr.push_back(i);
		}
		for (int j = 0; i * pr[j] <= N; ++j) {
			lp[i * pr[j]] = pr[j];
			if (pr[j] == lp[i]) {
				break;
			}
		}
	}

	int t;
	cin >> t;
	while(t--) {
		solve();
	}
	return 0;
}