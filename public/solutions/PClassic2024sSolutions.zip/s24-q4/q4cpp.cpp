#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;


void solve() {
    int n, f;
    cin >> n >> f;
    vector<int> desired_floors(n);
    for (int i = 0; i < n; i++) {
        cin >> desired_floors[i];
    }
    int c, te, ts;
    cin >> c >> te >> ts;
    sort(desired_floors.begin(), desired_floors.end(), std::greater<int>());
    int total = 0;

    for (int i = 0; i < c; i++) {
        total += desired_floors[i] * te;
    }
    for (int i = c; i < n; i++) {
        total += desired_floors[i] * ts;
    }
    cout << total << endl;

}

int main() {
    ios::sync_with_stdio(false);
	cin.tie(NULL);
    solve();
    return 0;
}