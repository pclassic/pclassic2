import java.util.*;
import java.lang.Math;

public class q4java {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int f = in.nextInt();
		in.nextLine();
		String s = in.nextLine();
		String[] splitArray = s.split(" ");
		int[] desired_floors = new int[splitArray.length];
		for (int j = 0; j < splitArray.length; j++) {
			desired_floors[j] = Integer.parseInt(splitArray[j]);
		}
		
		int c = in.nextInt();
		int te = in.nextInt();
		int ts = in.nextInt();
		System.out.println(elevator(n, f, desired_floors, c, te, ts));
		in.close();
	}
	
	public static int elevator(int n, int f, int[] desired_floors, int c, int te, int ts) {
		Arrays.sort(desired_floors);
		reverseArray(desired_floors);
		
		int total = 0;
		
		for (int floor = 0; floor < c; floor++) {
			total += desired_floors[floor] * te;
		}
		
		for (int floor = c; floor < desired_floors.length; floor++) {
			total += desired_floors[floor] * ts;
		}
		
		return total;
	}
	
	public static void reverseArray(int[] array) {
		for (int i = 0; i < array.length / 2; i++) {
	        int temp = array[i];
	        array[i] = array[array.length - 1 - i];
	        array[array.length - 1 - i] = temp;
	    }
	}
}