
def elevator(n, f, desired_floors, c, te, ts):
    desired_floors.sort(reverse=True)
    total = 0
    for floor in desired_floors[:c]:
        total += floor * te
    for floor in desired_floors[c:]:
        total += floor * ts
    return total

if __name__ == "__main__":
    n = int(input())
    f = int(input())
    desired_floors = [int(x) for x in input().split()]
    c = int(input())
    te = int(input())
    ts = int(input())
    print(elevator(n, f, desired_floors, c, te, ts))