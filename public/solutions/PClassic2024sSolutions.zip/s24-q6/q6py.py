def min_payment(owed):
    owed.sort()
    median = owed[len(owed)//2]
    total = 0
    for amount_owed in owed:
        total += abs(amount_owed - median)
    return total

if __name__ == "__main__":
    n = int(input())
    owed = [int(x) for x in input().split()]
    print(min_payment(owed))