#include <iostream>
#include <vector>
#include <cmath>
using namespace std;


void solve() {
    int n;
    cin >> n;
    vector<int> owed(n);
    for (int i = 0; i < n; i++) {
        cin >> owed[i];
    }
    sort(owed.begin(), owed.end());
    int median = owed[n/2];
    int total = 0;
    for (int i = 0; i < n; i++) {
        total += abs(owed[i] - median);
    }
    cout << total << endl;

}

int main() {
    ios::sync_with_stdio(false);
	cin.tie(NULL);
    solve();
}