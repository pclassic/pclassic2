import java.util.*;
public class q6java {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] owed = new int[n];
        for (int j = 0; j < n; j++) {
            owed[j] = in.nextInt();
        }
        System.out.println(min_payment(owed));
        in.close();
    }
    static int min_payment(int[] owed) {
        Arrays.sort(owed);
        int median = owed[owed.length / 2];
        int total = 0;
        for (int i: owed) {
            total += Math.abs(i - median);
        }
        return total;
    }
}