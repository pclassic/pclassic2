#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<ll,ll> pii;

void solve() {
	int n, m;
	cin >> n >> m;
	vector<vector<pii>> t(n);
	for(int i = 0; i < n-1; i++) {
		int u, v, w;
		cin >> u >> v >> w;
		u--; v--;
		t[u].pb({v,w});
		t[v].pb({u,w});
	}
	vector<array<int,3>> g;
	for(int i = 0; i < m-(n-1); i++) {
		int u, v, w;
		cin >> u >> v >> w;
		u--; v--;
		g.pb({u,v,w});
		g.pb({v,u,w});
	}

	vector<vector<pii>> adj = t;
	for(auto [u, v, w] : g) {
		adj[u].pb({v,w});
		adj[v].pb({u,w});
	}

	function<vi(int,vector<vector<pii>>&)> dijkstra = [&](int u, vector<vector<pii>>& adj) {
		int n = sz(adj);
		vi dist(n,LLONG_MAX/2), vis(n);
		priority_queue<pii> pq;
		dist[u] = 0;
		pq.push({-0,u});
		while(sz(pq)) {
			auto [d, u] = pq.top();
			pq.pop();
			if(vis[u]) continue;
			vis[u] = true;
			for(auto [v, w] : adj[u]) {
				if(dist[u]+w < dist[v]) {
					dist[v] = dist[u]+w;
					pq.push({-dist[v], v});
				}
			}
		}
		return dist;
	};

	vi ans;
	for(int i = 0; i < n; i++) {
		vi dg = dijkstra(i, adj);
		vi dt = dijkstra(i, t);
		// cout << i << ":" << endl;
		// for(int x : dg) cout << x << " ";
		// cout << endl;
		// for(int x : dt) cout << x << " ";
		// cout << endl;
		bool good = true;
		for(int j = 0; j < n; j++) {
			if(dg[j] != dt[j]) good = false;
		}
		if(good) ans.pb(i);
	}

	cout << sz(ans) << nl;
	for(int x : ans) cout << (x+1) << " ";
	cout << nl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	solve();
	return 0;
}