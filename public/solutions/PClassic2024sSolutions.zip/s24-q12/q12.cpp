#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<ll,ll> pii;

vector<vi> treeJump(vi& P){
	int on = 1, d = 1;
	while(on < sz(P)) on *= 2, d++;
	vector<vi> jmp(d, P);
	rep(i,1,d) rep(j,0,sz(P))
		jmp[i][j] = jmp[i-1][jmp[i-1][j]];
	return jmp;
}

int jmp(vector<vi>& tbl, int nod, int steps){
	rep(i,0,sz(tbl))
		if(steps&(1<<i)) nod = tbl[i][nod];
	return nod;
}

int lca(vector<vi>& tbl, vi& depth, int a, int b) {
	if (depth[a] < depth[b]) swap(a, b);
	a = jmp(tbl, a, depth[a] - depth[b]);
	if (a == b) return a;
	for (int i = sz(tbl); i--;) {
		int c = tbl[i][a], d = tbl[i][b];
		if (c != d) a = c, b = d;
	}
	return tbl[0][a];
}

ll tdist(vi& dist, int u, int v, int l) {
	return dist[u]+dist[v]-2*dist[l];
}


void solve() {
	int n, m;
	cin >> n >> m;
	vector<vector<pii>> t(n);
	for(int i = 0; i < n-1; i++) {
		int u, v, w;
		cin >> u >> v >> w;
		u--; v--;
		t[u].pb({v,w});
		t[v].pb({u,w});
	}
	vector<array<int,3>> g;
	for(int i = 0; i < m-(n-1); i++) {
		int u, v, w;
		cin >> u >> v >> w;
		u--; v--;
		g.pb({u,v,w});
		g.pb({v,u,w});
	}

	vi dist(n), par(n), depth(n);
	function<void(int,int)> dfs = [&](int u, int p) {
		for(auto [v, w] : t[u]) {
			if(v == p) continue;
			dist[v] = dist[u]+w;
			depth[v] = depth[u]+1;
			par[v] = u;
			dfs(v, u);
		}
	};
	dfs(0, -1);

	vvi tbl = treeJump(par);

	vi pre(n);
	for(auto [u, v, w] : g) {
		int l = lca(tbl, depth, u, v);
		ll d = dist[u]+dist[v]-2*dist[l];
		if(w >= d) continue;
		if(tdist(dist, l, u, l)+w >= tdist(dist, l, v, l)) {
			int x = u; // highest bad vertex
			for(int i = sz(tbl)-1; i >= 0; i--) {
				int y = tbl[i][x];
				bool cond = tdist(dist, y, u, y)+w < tdist(dist, y, v, l);
				if(cond) x = y;
			}
			pre[x]++;
		} else {
			int x = v; // highest good vertex
			for(int i = sz(tbl)-1; i >= 0; i--) {
				int y = tbl[i][x];
				bool cond = tdist(dist, y, u, l)+w >= tdist(dist, y, v, y);
				if(cond) x = y;
			}
			pre[0]++;
			pre[x]--;
		}
	}

	function<void(int,int)> dfs2 = [&](int u, int p) {
		for(auto [v, w] : t[u]) {
			if(v == p) continue;
			pre[v] += pre[u];
			dfs2(v, u);
		}
	};
	dfs2(0, -1);

	vi ans;
	for(int i = 0; i < n; i++) {
		if(pre[i] == 0) ans.pb(i);
	}

	cout << sz(ans) << nl;
	for(int x : ans) cout << (x+1) << " ";
	cout << nl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	solve();
	return 0;
}