import math

def get_result(a, b, c):
    if (a*b - c == 0) or (a*c - b == 0) or (b*c - a == 0) \
        or ((a-b) * c == 0) or ((a-c) * b == 0) or ((b-c) * a == 0) \
        or ((b-a) * c == 0) or ((c-a) * b == 0) or ((c-b) * a == 0):
        return "YES"
    return "NO"
    

if __name__ == "__main__":
    abc = [int(x) for x in input().split()]
    print(get_result(abc[0], abc[1], abc[2]))