import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.Math;

public class q2java {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        String s = br.readLine();
        String[] s_split = s.split(" ");
        int[] vals = new int[3];
        for (int i=0; i < 3; i++) {
            vals[i] = Integer.parseInt(s_split[i]);
        }

        System.out.println(get_result(vals[0], vals[1], vals[2]));
        
	}
	
	public static String get_result(int a, int b, int c) {
        if (a*b - c == 0 || a*c - b == 0 || b*c - a == 0
        || (a-b)*c == 0 || (a-c)*b == 0 || (b-c)*a == 0
        || (b-a)*c == 0 || (c-a)*b == 0 || (c-b)*a == 0) {
            return "YES";
        }
        return "NO";
    }
}