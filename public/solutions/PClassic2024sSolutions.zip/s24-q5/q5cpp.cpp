#include <vector>
#include <math.h>
#include <iostream>
#include <bits/stdc++.h>
#include <sstream>
#include <string>

using namespace std;

// input: vector of all positive elements
// ouput: maximum absolute sum difference
int solution(int size, vector<int> input)
{
    vector<int> difference;
    int max_val = INT_MIN, min_val = INT_MAX;

    // get max, min value of the entire array
    for (int i = 0; i < size; i++)
    {
        if (input[i] > max_val)
            max_val = input[i];

        if (input[i] < min_val)
            min_val = input[i];
    }

    int sum = 0;
    for (int i = 0; i < size; i++)
    {
        sum += fmax(abs(max_val - input[i]), abs(input[i] - min_val));
    }

    return sum;
}

int main()
{

    // Read the size of the array
    int arr_size;
    cin >> arr_size;

    // Clear the input buffer
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    // Read the array
    string arr_str;
    getline(cin, arr_str);

    stringstream ss(arr_str);
    vector<int> arr;
    int number;

    // string -> vector
    while (ss >> number)
    {
        arr.push_back(number);
    }

    cout << solution(arr_size, arr) << endl;

    return 0;
}