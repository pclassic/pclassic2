def maxAbsDiffSum(n, lst):
    r = 0
    l = float('inf')

    for i in range(n):
        if lst[i] > r:
            r = lst[i]
        if lst[i] < l:
            l = lst[i]
    
    total = 0
    for i in range(n):
        total += max(abs(lst[i] - r), abs(lst[i] - l))
    return total

if __name__ == "__main__":
    n = int(input())
    lst = [int(x) for x in input().split()]

    print(maxAbsDiffSum(n, lst))