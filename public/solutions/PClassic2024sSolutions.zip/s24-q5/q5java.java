import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q5java {

    public static long maxAbsDiffSum(int n, int[] a) {
        int max = 0;
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            if (a[i] > max) {
                max = a[i];
            }
            if (a[i] < min) {
                min = a[i];
            }
        }
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += Math.max(Math.abs(a[i] - max), Math.abs(a[i] - min));
        }
        return sum;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String[] aStrings = br.readLine().split(" ");
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = Integer.parseInt(aStrings[i]);
        }

        System.out.println(Long.toString(maxAbsDiffSum(n, a)));
    }
}