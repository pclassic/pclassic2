#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define pb push_back
#define F first
#define S second
#define nl "\n"
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;
typedef pair<int,int> pii;

void solve() {
	int n, m;
	cin >> n >> m;
	vvi x(n, vi(m));
	for(int i = 0; i < n; i++) {
		for(int j = 0; j < m; j++) {
			cin >> x[i][j];
		}
	}

	ll ans = 0;
	for(int i = 0; i < n; i++) {
		ans += x[i][0];
	}
	for(int i = 1; i < m; i++) {
		ans += x[n-1][i];
	}

	for(int i = 0; i < n-1; i++) {
		for(int j = 1; j < m; j++) {
			ans = gcd(ans, (ll)abs(x[i][j]-x[i+1][j-1]));
		}
	}

	cout << ans << nl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	int t;
	cin >> t;
	while(t--) {
		solve();
	}
	return 0;
}
