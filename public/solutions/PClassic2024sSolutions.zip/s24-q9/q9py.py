import math
def solve():
    t = [int(x) for x in input().split()]
    n = t[0]
    m = t[1]

    lst = [[0 for _ in range(m)] for _ in range(n)]
    for i in range(n):
        t = [int(x) for x in input().split()]
        for j in range(m):
            lst[i][j] = t[j]

    ans = 0
    for i in range(n):
        ans += lst[i][0]
    
    for i in range(1, m):
        ans += lst[n-1][i]
    
    for i in range(n-1):
        for j in range(1, m):
            ans = math.gcd(ans, abs(lst[i][j] - lst[i+1][j-1]))

    print(ans)

if __name__ == "__main__":
    t = int(input())
    for i in range(t):
        solve()