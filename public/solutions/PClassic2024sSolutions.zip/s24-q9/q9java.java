import java.util.*;
import java.io.*;
public class q9java {
    static BufferedReader bf;
    public static void main(String[] args) throws IOException {
        bf = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(bf.readLine());
        while (t-- > 0) {
            solve();
        }
    }
    static void solve() throws IOException {
        int n, m;
        String[] l1 = bf.readLine().split(" ");
        n = Integer.parseInt(l1[0]);
        m = Integer.parseInt(l1[1]);
        int[][] x = new int[n][m];
        long ans = 0;
        for (int i = 0; i < n; i++) {
            String[] l2 = bf.readLine().split(" ");
            for (int j = 0; j < m; j++) {
                x[i][j] = Integer.parseInt(l2[j]);
            }
        }
        for(int i = 0; i < n; i++) {
            ans += x[i][0];
        }
        for(int i = 1; i < m; i++) {
            ans += x[n-1][i];
        }
        for(int i = 0; i < n-1; i++) {
            for(int j = 1; j < m; j++) {
                ans = gcd(ans, (long)(Math.abs(x[i][j]-x[i+1][j-1])));
            }
        }
        System.out.println(ans);
    
    }
    public static long gcd(long a, long b) {
        if (b==0) return a;
        return gcd(b,a%b);
     }
}
