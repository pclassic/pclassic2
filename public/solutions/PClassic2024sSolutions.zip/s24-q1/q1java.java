import java.io.BufferedReader;
import java.io.InputStreamReader;

public class q1java {

    public static char get_char(String s, int k) {
        if (k % (s.length()) == 0) {
            return s.charAt(s.length() - 1);
        } else {
            return s.charAt(k % (s.length()) - 1);
        }
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        int k = Integer.parseInt(br.readLine());
        System.out.println(get_char(s, k));

    }
}