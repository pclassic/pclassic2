def get_char(s, k):
   return s[(k % len(s)) - 1]

if __name__ == "__main__":
     s = input()
     k = int(input())
     print(get_char(s, k))