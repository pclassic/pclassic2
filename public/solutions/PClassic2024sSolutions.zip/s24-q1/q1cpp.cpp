#include <iostream>
#include <vector>
#include <cmath>
#include <string>
using namespace std;

void solve() {
    string s;
    int k;
    cin >> s;
    cin >> k;
    if (k%s.length() == 0) {
        cout << s[s.length() - 1] << endl;
    } else {
        cout << s[(k % s.length()) - 1] << endl;
    }
}

int main() {
    ios::sync_with_stdio(false);
	cin.tie(NULL);
    solve();
    return 0;
}